<?php $db = mysqli_connect('localhost','root','','nrcb');
if(mysqli_connect_errno()){
    echo 'Database connection failed with these erros '.mysqli_connect_error();
    die();
}
?>