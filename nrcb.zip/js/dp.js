
    // if desktop device, use DateTimePicker
    $("#datetimepicker").datetimepicker({
         keepOpen: false,
        format: 'DD-MM-YYYY hh:mm:A',
      icons: {
        time: "fa fa-clock-o",
        date: "fa fa-calendar",
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down",
        next: "fa fa-chevron-right",
        previous: "fa fa-chevron-left"
      }
    });

    $("#datetimepicker2").datetimepicker({
        format: 'DD-MM-YYYY hh:mm:A',
      icons: {
        time: "fa fa-clock-o",
        date: "fa fa-calendar",
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down",
        next: "fa fa-chevron-right",
        previous: "fa fa-chevron-left"
      }
    });
    
    $("#datepicker").datetimepicker({
      useCurrent: true,
      format: "L",
      icons: {
        next: "fa fa-chevron-right",
        previous: "fa fa-chevron-left"
      }
    });
    $("#timepicker").datetimepicker({
      format: "LT",
      icons: {
        up: "fa fa-chevron-up",
        down: "fa fa-chevron-down"
      }
    });
  