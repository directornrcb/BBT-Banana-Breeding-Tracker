<?php
require_once "core/init.php";
include "core/helpers.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Embryo Culture</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

    <div class="container">
        <div class="row">
        <hr>
            <div class="col-md-8 col-md-offset-2 form-shadow">
                <h3 class="text-center">Embryo Culture</h3>
                <form action="form3b.php" method="get">
                <div class="form-group">
                <label for="id">ID Number*</label>
                <input type="text" name="id" placeholder="Enter ID Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="dates">Date of Seed Received at lab*</label>
                <div class="input-group date-time" id="datetimepicker">
                <input class="form-control" name="dates"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
                </div>
                <div class="form-group">
                <label for="nseeds">Number of Seeds*</label>
                <input type="text" name="nseeds" placeholder="Enter Number of seeds" required class="form-control">
                </div>
                <div class="form-group">
                <label for="nsseeds">Number of Sunken Seeds*</label>
                <input type="text" name="nsseeds" placeholder="Enter Number of Sunken seeds" required class="form-control">
                </div>
                <div class="form-group">
                <label for="remark1">Remarks</label>
                <input type="text" name="remark1" placeholder="Remarks"  class="form-control">
                </div>
                <div class="form-group">
                <label for="nfseeds">Number of Floating Seeds*</label>
                <input type="text" name="nfseeds" placeholder="Enter Number of Floating seeds" required class="form-control">
                </div>
                <div class="form-group">
                <label for="remark2">Remarks</label>
                <input type="text" name="remark2" placeholder="Remarks"  class="form-control">
                </div>
                <div class="form-group">
                <label for="nseedsa">Number of Seeds After Washing*</label>
                <input type="text" name="nseedsa" placeholder="Enter Number of seeds After Washing" required class="form-control">
                </div>
                <div class="form-group">
                <label for="nembryo">Number of embryo Initiated*</label>
                <input type="text" name="nembryo" placeholder="Number of embryo Initiated" required class="form-control">
                </div>
                <div class="form-group">
                <label for="datee">Date of embryo culture*</label>
                <div class="input-group date-time" id="datetimepicker2">
                <input class="form-control" name="datee"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
                </div>
                <div class="form-group">
                <label for="media">Media Details*</label>
                <input type="text" name="media" placeholder="Media Details" required class="form-control">
                </div>
                <div class="form-group">
                <label for="nameofp">Name of the person*</label>
                <input type="text" name="nameofp" placeholder="Name" required class="form-control">
                </div>
                <div class="form-group">
                <a href="index.php" class="float-left btn btn-info btn-lg "><i class="fa fa-chevron-left" aria-hidden="true"></i> Back</a>
                <input type="submit" Value="Submit" class="float-right btn btn-success btn-lg mb-7">
                </div>


                </form>
            </div>      
        </div>
    </div>
    <footer>
    
    <p class="text-center">NRCB</p>
    </footer>
</body>

    <!-- jQuery library -->
   <!--  <script src="js/jquery.js"></script> -->

<script src="js/jquery224.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/datetime.js"></script>
<script  src="js/dp.js"></script>



</html>

