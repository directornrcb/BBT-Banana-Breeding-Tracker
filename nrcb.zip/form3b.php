<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form 3</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

     <!-- Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<?php
if($_POST){
    
    $id = $_POST['id'];
    $dates = $_POST['dates'];
    $nseeds = $_POST['nseeds'];
    $nsseeds = $_POST['nsseeds'];
    $remark1 = $_POST['remark1'];
    $nfseeds = $_POST['nfseeds'];
    $remark2 = $_POST['remark2'];
    $nseedsa = $_POST['nseedsa'];
    $nembryo = $_POST['nembryo'];
    $datee = $_POST['datee'];
    $media = $_POST['media'];
    $nameofp = $_POST['nameofp'];

    $result = $db->query("SELECT * FROM hybridization WHERE id = $id");
    $num_rows = mysqli_num_rows($result);

    if($num_rows == 0){
        echo '<h3 class="text-center text-danger">Invalid ID given</h3>';
        $errors = 'No Row found';
        echo '<div class="text-center"><a href="form3a.php" class="text-info text-center">Try Again!</a></div>';
        die();
    }


    if(!empty($errors)){
        echo display_errors($errors);
    }else{
        
        $query = "UPDATE hybridization SET doseedreceivedatlab = '$dates', noseeds = '$nseeds', nosunkenseeds = '$nsseeds' , remark1 = '$remark1' , nofloatingseeds = '$nfseeds' , remark2 = '$remark2' , noseedafterwashing = '$nseedsa' , noembryoinitiated = '$nembryo' , doembryoculture = '$datee' , media = '$media' , nameofperson = '$nameofp' WHERE id = '$id' ";
        //echo $query;
        $db->query($query);
        
        $query = "SELECT * FROM hybridization WHERE id = $id";
        $results =  $db->query($query);
        $results = mysqli_fetch_assoc($results);
        $name = $results['name'];
        $pnumber = $results['pnumber'];
        $fparent = $results['fparent'];
        $mparent = $results['mparent'];
        $totalseeds = $results['noseedsextracted'];
        $fptype = $results['fptype'];
        $mptype = $results['mptype'];
        $fgenome = $results['fgenome'];
        $mgenome = $results['mgenome'];



        $qr3 = "ID: $id Field Name : $name Plant Number : $pnumber Female Parent : $fparent Female Parent Genome: $fgenome Male Parent : $mparent Male Parent Genome: $mgenome Total Number of Seeds : $totalseeds Date of Seed Receiving at lab : $dates Date of embryo culture : $datee ";


        $db->query("UPDATE hybridization SET qr3='$qr3' WHERE id='$id'");
        ?>
        <h3 class="text-center text-success mb-20">Updated Successfully</h3>
    <hr>
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-6">
    <p class="text-center">QR Code:</p>
    <?php 
            $qrcontent = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome: $fgenome \nMale Parent : $mparent \nMale Parent Genome: $mgenome \nTotal Number of Seeds : $totalseeds \nDate of Seed Receiving at lab : $dates \nDate of embryo culture : $datee";
            $qrcontent = stripslashes($qrcontent);
            $qrname = "QR3";
            
            include "qr.php";
    ?>
    
    </div>
    <div class="col-md-6">
        <h4 class="text-center">Updated Details</h4>
    <table class="table table-hover table-bordered table-condensed table-striped ">
    <thead>
    <th>Title</th>
    <th>Values</th>
    </thead>
    <tr>
        <td>ID</td>
        <td><?=$id?></td>
    </tr>
    <tr>
        <td>Field Name</td>
        <td><?=$name?></td>
    </tr>
    <tr>
        <td>Plant Number</td>
        <td><?=$pnumber?></td>
    </tr>
    <tr>
        <td>Female Parent</td>
        <td><?=$fparent?></td>
    </tr>
    <tr>
        <td>Female Parent Genome</td>
        <td><?=$fgenome?></td>
    </tr>
    <tr>
        <td>Male Parent</td>
        <td><?=$mparent?></td>
    </tr>
    <tr>
        <td>Male Parent Genome</td>
        <td><?=$mgenome?></td>
    </tr>
    <tr>
        <td>Total Number of Seeds</td>
        <td><?=$totalseeds?></td>
    </tr>
    <tr>
        <td>Date of seed receiving at lab</td>
        <td><?=$dates?></td>
    </tr>
    <tr>
        <td>Date of embryo culture</td>
        <td><?=$datee?></td>
    </tr>

    

    </table>
    </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-2 col-md-offset-5">
          <a href="form3a.php" class="btn btn-info centered">Make Another Submission!</a>
        </div>
    </div>

        <?php
    }

}
if($_GET){
?>

 <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 mt-30">
            <h3 class="text-center">Make Sure Your Inputs are correct!</h3>
            <form action="form3b.php" method="post">
            <table class="table table-bordered table-hover table-striped">
           

                <tr>
                    <td>ID Number</td>
                    <td><?=$_GET["id"]?><input type="hidden" name="id" value="<?=$_GET["id"]?>"></td>
                </tr>
                <tr>
                    <td>Date of Seed Received at Lab</td>
                    <td><?=$_GET["dates"]?><input type="hidden" name="dates" value="<?=$_GET["dates"]?>"></td>
                </tr>
                <tr>
                    <td>Number of Seeds</td>
                    <td><?=$_GET["nseeds"]?><input type="hidden" name="nseeds" value="<?=$_GET["nseeds"]?>"></td>
                </tr>
                <tr>
                    <td>Number of Sunken Seeds</td>
                    <td><?=$_GET["nsseeds"]?><input type="hidden" name="nsseeds" value="<?=$_GET["nsseeds"]?>"></td>
                </tr>
                <tr>
                    <td>Remarks</td>
                    <td><?=$_GET["remark1"]?><input type="hidden" name="remark1" value="<?=$_GET["remark1"]?>"></td>
                </tr>
                <tr>
                    <td>Number of Floating Seeds</td>
                    <td><?=$_GET["nfseeds"]?><input type="hidden" name="nfseeds" value="<?=$_GET["nfseeds"]?>"></td>
                </tr>
                <tr>
                    <td>Remarks</td>
                    <td><?=$_GET["remark2"]?><input type="hidden" name="remark2" value="<?=$_GET["remark2"]?>"></td>
                </tr>
                <tr>
                    <td>Number of Seeds After washing</td>
                    <td><?=$_GET["nseedsa"]?><input type="hidden" name="nseedsa" value="<?=$_GET["nseedsa"]?>"></td>
                </tr>
                <tr>
                    <td>Number of embryo Initiated</td>
                    <td><?=$_GET["nembryo"]?><input type="hidden" name="nembryo" value="<?=$_GET["nembryo"]?>"></td>
                </tr>
                <tr>
                    <td>Date of embryo culture</td>
                    <td><?=$_GET["datee"]?><input type="hidden" name="datee" value="<?=$_GET["datee"]?>"></td>
                </tr>
                <tr>
                    <td>Media Details</td>
                    <td><?=$_GET["media"]?><input type="hidden" name="media" value="<?=$_GET["media"]?>"></td>
                </tr>
                <tr>
                    <td>Name of Person</td>
                    <td><?=$_GET["nameofp"]?><input type="hidden" name="nameofp" value="<?=$_GET["nameofp"]?>"></td>
                </tr>
                
                
            </table>
                <div class="col-md-6 col-md-offset-3">
                    <div class="col-md-4 col-sm-4 col-xs-4"><input type="submit" class="btn btn-success" value="Correct"></div>
                    <div class="col-md-4 col-sm-4 col-xs-4"> <a href="form3a.php" class="btn btn-info">Re-Enter</a></div>
                </div>
            </form>

            </div>
        </div>
    </div>
</div>

<?php

}

?>

</body>