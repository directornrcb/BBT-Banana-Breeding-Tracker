
<?php
copy('https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=ID:%205%20%0AField%20Name%20:%20test%20%0APlant%20Number%20:%2012%20%0AFemale%20Parent%20:%2012%20(Triploid)%20%0AMale%20Parent%20:%2012%20(Tetraploid)%20%0ADate%20of%20Crossing%20:%2012-10-2018%2012:00:AM%20%0ADate%20of%20Bunch%20Harvested%20:%2004-10-2018%2012:00:AM%20%0ADate%20of%20Seed%20Extration%20:%2002-10-2018%2004:01:AM%20%0ATotal%20Number%20of%20Seeds%20:%2023.&choe=UTF-8', 'temo/qr.jpg');


?>