

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home | NRCB</title>

      <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    

    <style>
    h3{
        font-size:19px!important;
        font-family: muli;
    }
    </style>

</head>
<body class="home">
    <div class="container-fluid">
        <div class="row">
           <div class="col-md-1 col-xs-3">
               <img class="img-responsive" src="img/icarlogo.png" width="70px" alt="" >
           </div>
           <div class="col-md-10 col-xs-6">
               <h1 class="h1" >BANANA BREEDING TRACKER DATABASE</h1>
           </div>
           <div class="col-md-1 col-xs-3">
               <img class="img-responsive" src="img/nrcblogo.png" width="93px" class="float-right" alt="" >
           </div>
        </div>
    </div>

    <div class="container">

        <div class="row">
        <div class="col-md-3">
        <div class="items">
        <a href="form1a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Hybridization</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form2a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Seed Extraction</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form3a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Embryo Culture</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form4a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Sub Culture (Shoot)</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form5a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Sub Culture (Root)</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form6a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Primary Hardening</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form7a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Secondary Hardening</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form8a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">IHIN</h3>
        </div>
        </div>
        </div>
    </div>

</body>
</html>