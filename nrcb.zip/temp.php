<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form 1</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <hr>
    <div>

    <?php
    if($_POST){
       // var_dump($_POST);
    //$errors[] = "here comes the error.";
    
    $name = $_POST['name'];
    $pnumber = $_POST['pnumber'];
    $fparent = $_POST['fparent'];
    $mparent = $_POST['mparent'];
    $nhybrid = $_POST['nhybrid'];
    $date = $_POST['date'];
    $mhybrid = $_POST['mhybrid'];
    $temperature = $_POST['temperature'];
    $humidity = $_POST['humidity'];
    $mhybrido = $_POST['others'];
    $breeder = $_POST['breeder'];
    ?>

    <?php
    if($mhybrid == "Others"){
        $mhybrid = $mhybrido;
    }
    if(!empty($errors)){
        echo display_errors($errors);
    }else{
        $query = "INSERT INTO hybridization (name,pnumber,fparent,mparent,nhybrid,mhybrid,temperature,humidity,breeder) VALUES ('$name','$pnumber','$fparent','$mparent','$nhybrid','$mhybrid','$temperature','$humidity','$breeder')";
       // echo $query;
        $db->query($query);
        
        $id = mysqli_insert_id($db);

        $qr1 = "ID : $id %0AField Name : $name %0APlant Number : $pnumber %0AFemale Parent : $fparent %0AMale Parent : $mparent %0ANumber of Hand Hybridized : $nhybrid %0AMethod of Hybridization : $mhybrid  Date of Hybridization : $date %0ATemperature : $temperature %0AHumidity : $humidity %0ABreeder : $breeder";
        $db->query("UPDATE hybridization SET qr1='$qr1' WHERE id='$id'");
        
    ?>
    

    <h3 class="text-center text-success mb-20">Updated Successfully</h3>
    <div class="row">
    <div class="col-md-6">
    <p class="text-center">QR Code:</p>
    <img class="qrimg" src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=ID : <?=$id?> %0AField Name : <?=$name?> %0APlant Number :<?=$pnumber?> %0AFemale Parent: <?=$fparent?> %0AMale Parent : <?=$mparent?> %0ANumber of Hand Hybridized : <?=$nhybrid?> %0ADate of Hybridization : <?=$date?> %0AMethod of Hybridization : <?=$mhybrid?> %0ATemperature : <?=$temperature?> %0AHumidity : <?=$humidity?> %0ABreeder : <?=$breeder?>.&choe=UTF-8" title="QR1" />
    </div>
    <div class="col-md-6">
    <table class="table table-hover table-bordered table-condensed table-striped ">
    <thead>
    <th>Title</th>
    <th>Values</th>
    </thead>
    <tr>
        <td>ID</td>
        <td><?=$id?></td>
    </tr>
    <tr>
        <td>Field Name</td>
        <td><?=$name?></td>
    </tr>
    <tr>
        <td>Plant Number</td>
        <td><?=$pnumber?></td>
    </tr>
    <tr>
        <td>Female parent</td>
        <td><?=$fparent?></td>
    </tr>
    <tr>
        <td>Male Parent</td>
        <td><?=$mparent?></td>
    </tr>
    <tr>
        <td>Number of hand hybrid</td>
        <td><?=$nhybrid?></td>
    </tr>
    <tr>
        <td>Method of Hybridization</td>
        <td><?=$mhybrid?></td>
    </tr>
    <tr>
        <td>Date of Hybridization</td>
        <td><?=$date?></td>
    </tr>
    <tr>
        <td>Temperature</td>
        <td><?=$temperature?></td>
    </tr>
    <tr>
        <td>Humidity</td>
        <td><?=$humidity?></td>
    </tr>
    <tr>
        <td>Breeder</td>
        <td><?=$breeder?></td>
    </tr>

    </table>
    </div>
    </div>
    <hr>
<div class="row">
<div class="col-md-2 col-md-offset-5">
<a href="form1.php" class="btn btn-info centered">Make Another Submission!</a>
</div>
</div>
    

    <?php
    }
    }else{
    ?>

    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 form-shadow">
                <h3 class="text-center">Hybridization</h3>
                <form action="form1.php" method="post">
                <div class="form-group">
                <label for="name">Field Name / Number*</label>
                <input type="text" name="name" placeholder="Field Name / Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="pnumber">Plant Number*</label>
                <input type="text" name="pnumber" placeholder="Enter Plant Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="fparent">Female Parent*</label>
                <input type="text" name="fparent" placeholder="Female Parentr" required class="form-control">
                </div>
                <div class="form-group">
                <label for="mparent">Male Parent*</label>
                <input type="text" name="mparent" placeholder="Male Parent" required class="form-control">
                </div>
                <div class="form-group">
                <label for="nhybrid">Number of Hand Hybridized*</label>
                <input type="text" name="nhybrid" placeholder="Number of Hand Hybridized" required class="form-control">
                </div>
                <div class="form-group">
                <label for="time">Date of Hybridization*</label>
                <p>
                <input type="datetime-local" name="date" placeholder="Date of Hybridization" class="form-control">
                </div>
                <div class="form-group">
                <label for="mhybrid">Method of Hybridization*</label>
                <select name="mhybrid" id="mhybrid" required class="form-control">
                <option value=""></option>
                <option value="single time hybridization method">single time hybridization method</option>
                <option value="Double time hybridization method">Double time hybridization method</option>
                <option value="PGM sprayed hybridization method">PGM sprayed hybridization method</option>
                <option value="Others">Others</option>
                </select>
                </div>
                <div class="form-group">
                <input type="hidden" name="others" placeholder="Enter Others" required class="form-control">
                </div>

                <div class="form-group">
                <label for="temperature">Temperature</label>
                <input type="text" name="temperature" placeholder="eg: 23" class="form-control">
                </div>
                <div class="form-group">
                <label for="humidity">Humidity</label>
                <input type="text" name="humidity" placeholder="eg: 23" class="form-control">
                </div>
                <div class="form-group">
                <label for="breeder">Name of the Breeder</label>
                <input type="text" name="breeder" placeholder="Enter Name" class="form-control">
                </div>
                <div class="form-group">
                <input type="submit" Value="Submit" class="float-right btn btn-success btn-lg ">
                </div>


                </form>
            </div>      
        </div>
    </div>
    <footer>
    
    <p class="text-center">NRCB</p>
    </footer>
</body>
<script>
$(document ).ready(function() {
    $('select[name=mhybrid]').change(function() { 
        var m;
        m = $(this).val();
        if(m == "Others"){
            $('input[name="others"]').prop('type', 'text');
        }else{
            $('input[name="others"]').prop('type', 'hidden');
        }
     });
 });
</script>


</html>

<?php
}
?>