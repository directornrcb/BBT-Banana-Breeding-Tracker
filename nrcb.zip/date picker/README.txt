A Pen created at CodePen.io. You can find this one at https://codepen.io/SkyHyzer/pen/NRyBZb.

 Custom bootstrap styling for Eonasdan's DateTimePicker.