<?php include('server.php') ?>
<?php
if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in to Access that page";
  	header('location: login.php');
	}
	
	?>
<!DOCTYPE html>
<html>
<head>

	
	
	<title>Register</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

	<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet'>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

	<style>
	@media screen and (min-width: 600px){
#login-form {
		width: 49%;
    height: auto;
    border: 2px solid lightgrey;
    box-shadow: 7px 7px 15px rgba(0,0,0,0.6);
    margin: 5% auto;
    padding: 15px;
    background: #e0f7fa36;
}
}
.text-success{
	color:#28a745!important
}
	</style>
</head>
<body>
  <div class="header">
  </div>
	<?php include('errors.php'); ?>
		<div class="col-md-12">
        <h2 class="text-center"><i class="fas fa-lock text-success"> </i> Add User</h2>
  <form method="post" id="login-form" action="register.php">

							<div class="text-danger">
															</div>
							<div class="text-danger">
												</div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" name="username" placeholder="Enter username" value="">
            </div>
						<div class="form-group">
                <label for="email">Email</label>
                <input type="text" class="form-control" name="email" placeholder="Enter Email" value="">
            </div>
            <div class="form-group">
                <label for="password_1">Password</label>
                <input type="password" class="form-control" name="password_1" placeholder="Password" value="">
            </div>
						<div class="form-group">
                <label for="password_2">Password</label>
                <input type="password" class="form-control" name="password_2" placeholder="Confirm your password" value="">
            </div>
            <div class="form-group">
            <button type="submit" name="reg_user" class="btn btn-success width-100 mb-20">Add User</button>
            </div>
<a class="float-right" href="results.php" >View Results</a>           


        </div>

  </form>
</body>
</html>