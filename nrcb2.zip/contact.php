


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact | NRCB</title>


    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">




    

    <style>
    body{
      font-family: muli!important;
    }
    h3{
        font-size:19px!important;
        
    }
    .fa{
      padding-right:10px;
    }
    a{
      color:#5e4d83;
    }
    .fa-phone{
      font-size: 20px;
    }
    h4{
      padding-bottom: 8px;
    border-bottom: solid 2px #b098d9;
    font-weight:bold;
    }
    @media (max-width: 580px){
      .col-md-3{
        padding:40px;
      }
    }
    .col-md-3:hover {
    box-shadow: 0px 0px 20px 2px #797099;
    margin-top: -20px;
}
.pt-8{
  padding-top: 8px;
}
.col-md-3:hover {
    box-shadow: 0px 0px 20px 2px #c0c0c0;
    margin-top: -20px;
    transition-duration: 0.5s;
}
.height-400{
  height: 400px;
}
a:hover{
  color:#3d2d60;
}

    </style>

</head>
<body class="home padding-0" >
    <div class="container-fluid head" style="padding:0px;">
    <div class="row margin-0">
    <div class="col-md-12 padding-0">
        <a class="w--current" href="index.php">
        <img src="img/head.png" class="width-100" alt="Logo">
        </a>
        
    </div>
    </div>
    </div>

   

    <div class="container" style="padding:0px;">
    <nav class="navbar navbar-expand-lg navbar-light bg-light justify-content-center">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto text-center centered bold">
      <li class="nav-item ">
        <a class="nav-link" href="index.php">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="bbt.php">BBtbase</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact Us<span class="sr-only">(current)</span></a>
      </li>
    </ul>

  </div>
</nav>

<section style="padding-top:10px;border-top: 2px solid #00c3c547;">

</section>

        <div class="row">
        <div class="col-md-3 height-400">
          <h4 class="pt-8">Dr. S. UMA</h4>
          <p>The Director <br>
          National Research Centre for Banana <br>
          <span class="small">(Indian Council of Agricultural Research)</span>
          Thogamalai Road,<br>
          Thayanur Post,<br>
          Tiruchirapalli - 620 102. <br>
          Tamil Nadu, India.
        </p>
        <a href="tel:9442553117"><i class="fa fa-phone" aria-hidden="true"></i>9442553117</a><br>
        <a href="mailto:nrcbdirector@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i>nrcbdirector@gmail.com</a><br>
        <a href="mailto:directornrcb@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i>directornrcb@gmail.com</a> <br>
        <a href="mailto:nrcbanana@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i>nrcbanana@gmail.com</a><br>
        <a href="www.nrcb.res.in"><i class="fa fa-globe" aria-hidden="true"></i>www.nrcb.res.in</a>

        </div>
        <div class="col-md-3 height-400">
          <h4 class="pt-8">Dr. S. Backiyarani </h4>
          <p>Principal Scientist (Hort.) and Head
      Crop Improvement Division<br>
          National Research Centre for Banana <br>
          <span class="small">(Indian Council of Agricultural Research)</span>
          Thogamalai Road,<br>
          Thayanur Post,<br>
          Tiruchirapalli - 620 102. <br>
          Tamil Nadu, India.
        </p>
        <a href="tel:9442553117"><i class="fa fa-phone" aria-hidden="true"></i>9442583117</a><br>
        <a href="mailto:backiyarani@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i>backiyarani@gmail.com</a><br>
       

        </div>
        <div class="col-md-3 height-400">
          <h4 class="pt-8">Dr. MS. Saraswathi</h4>
          <p>Principal Scientist, <br>
          Crop Improvement Division <br>
          National Research Centre for Banana <br>
          <span class="small">(Indian Council of Agricultural Research)</span>
          Thogamalai Road,<br>
          Thayanur Post,<br>
          Tiruchirapalli - 620 102. <br>
          Tamil Nadu, India.
        </p>
     
        </div>
        <div class="col-md-3 height-400">
          <h4 class="pt-8">Mr. Vignesh Kumar. B</h4>
          <p>Ph D Scholar,<br>
          Department of Biotechnology, <br>
          Crop Improvement Division,<br>
          <span class="small">(Indian Council of Agricultural Research)</span>
          Thogamalai Road,<br>
          Thayanur Post,<br>
          Tiruchirapalli - 620 102. <br>
          Tamil Nadu, India.
        </p>
        <a href="tel:8903625490"><i class="fa fa-phone" aria-hidden="true"></i>8903625490</a><br>
        <a href="mailto:vigneshkumar591@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i>vigneshkumar591@gmail.com</a><br>
     
        </div>
        
        </div>
    </div>
<!-- Footer -->
<section></section>
<div class="footer-copyright text-center py-3 " style="
    background: #673ab785;">© 2018 Copyright:
      <a style="color:white;" href="http://nrcb.res.in/">ICAR- National Research Centre for Banana. All Rights Reserved.</a>
    </div>

</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script>

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 280) {
        //clearHeader, not clearheader - caps H
        $(".navbar").addClass("fixed-top");
    }
    if (scroll < 280) {
        //clearHeader, not clearheader - caps H
        $(".navbar").removeClass("fixed-top");
    }
}); 
</script>
</html>
