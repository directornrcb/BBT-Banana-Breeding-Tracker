<?php
require_once "core/init.php";
include "core/helpers.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hybridization</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 form-shadow">
                <h3 class="text-center">Hybridization</h3>
                <form action="form1b.php" method="get">
                <div class="form-group">
                <label for="name">Field Name / Number*</label>
                <input type="text" name="name" placeholder="Field Name / Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="pnumber">Plant Number*</label>
                <input type="text" name="pnumber" placeholder="Enter Plant Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="fparent">Female Parent*</label>
                <input type="text" name="fparent" placeholder="Female Parentr" required class="form-control">
                </div>
                <div class="form-group">
                <label class="radio-inline"><input id="f1" type="radio" name="ftype" value="Diploid" required>Diploid</label>
                <label class="radio-inline"><input id="f2" type="radio" name="ftype" value="Triploid">Triploid</label>
                <label class="radio-inline"><input id="f3" type="radio" name="ftype" value="Tetraploid">Triploid</label>
                </div>
                <div class="form-group fgenome"  style="display:none;">
                <label for="fgenome">Genome</label>
                <select name="fgenome" id="genome" required class="form-control">
                <option id="optionf1" value="AA">AA</option>
                <option id="optionf2" value="AB">AB</option>
                <option id="optionf3" value="BB">BB</option>
                <option id="optionf4" value="" style="display:none"></option>
                </select>
                </div>
                <div class="form-group">
                <label for="mparent">Male Parent*</label>
                <input type="text" name="mparent" placeholder="Male Parent" required class="form-control">
                </div>
                <div class="form-group">
                <label class="radio-inline"><input id="m1" type="radio" name="mtype" value="Diploid" required>Diploid</label>
                <label class="radio-inline"><input id="m2" type="radio" name="mtype" value="Triploid">Triploid</label>
                <label class="radio-inline"><input id="m3" type="radio" name="mtype" value="Tetraploid">Tetraploid</label>
                </div>
                <div class="form-group mgenome"  style="display:none;">
                <label for="mgenome">Genome</label>
                <select name="mgenome" id="genome" required class="form-control">
                <option id="option1" value="AA">AA</option>
                <option id="option2" value="AB">AB</option>
                <option id="option3" value="BB">BB</option>
                <option id="option4" value="" style="display:none"></option>
                </select>
                </div>
                <div class="form-group">
                <label for="nhybrid">Number of Hand Hybridized*</label>
                <input type="text" name="nhybrid" placeholder="Number of Hand Hybridized" required class="form-control">
                </div>
                <div class="form-group">
                <label for="time">Date of Hybridization*</label>
                <div class="input-group date-time" id="datetimepicker">
                <input type="text" class="form-control" name="date"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
                </div>
                <div class="form-group">
                <label for="mhybrid">Method of Hybridization*</label>
                <select name="mhybrid" id="mhybrid" required class="form-control">
                <option value=""></option>
                <option value="single time hybridization method">single time hybridization method</option>
                <option value="Double time hybridization method">Double time hybridization method</option>
                <option value="PGM sprayed hybridization method">PGM sprayed hybridization method</option>
                <option value="Others">Others</option>
                </select>
                </div>
                <div class="form-group">
                <input type="hidden" name="others" placeholder="Enter Others" required class="form-control">
                </div>

                <div class="form-group">
                <label for="temperature">Temperature</label>
                <input type="text" name="temperature" placeholder="eg: 23" class="form-control">
                </div>
                <div class="form-group">
                <label for="humidity">Humidity</label>
                <input type="text" name="humidity" placeholder="eg: 23" class="form-control">
                </div>
                <div class="form-group">
                <label for="breeder">Name of the Breeder</label>
                <input type="text" name="breeder" placeholder="Enter Name" class="form-control">
                </div>
                
                <div class="form-group">
                <a href="index.php" class="float-left btn btn-info btn-lg "><i class="fa fa-chevron-left" aria-hidden="true"></i> Back</a>
                <input type="submit" Value="Submit" class="float-right btn btn-success btn-lg ">
                </div>


                </form>
            </div>      
        </div>
    </div>
    <footer>
    
    <p class="text-center">NRCB</p>
    </footer>
</body>



<script src="js/jquery224.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/datetime.js"></script>
<script  src="js/dp.js"></script>

<script>
$(document ).ready(function() {
    $('select[name=mhybrid]').change(function() { 
        var m;
        m = $(this).val();
        if(m == "Others"){
            $('input[name="others"]').prop('type', 'text');
        }else{
            $('input[name="others"]').prop('type', 'hidden');
        }
     });
 });
</script>

<script>
$(document).ready(function() {
    $('#m1').click(function(){
        $(".mgenome").css("display", "block");
        $("#option4").css("display", "none");
        $("#option1").val("AA");
        $("#option1").text("AA");
        $("#option2").val("BB");
        $("#option2").text("BB");
        $("#option3").val("AB");
        $("#option3").text("AB");
    })
    $('#m2').click(function(){
        $(".mgenome").css("display", "block");
        $("#option4").css("display", "none");
        $("#option1").val("AAA");
        $("#option1").text("AAA");
        $("#option2").val("AAB");
        $("#option2").text("AAB");
        $("#option3").val("ABB");
        $("#option3").text("ABB");
    })
    $('#m3').click(function(){
        $(".mgenome").css("display", "block");
        $("#option1").val("AAAA");
        $("#option1").text("AAAA");
        $("#option2").val("AAAB");
        $("#option2").text("AAAB");
        $("#option3").val("AABB");
        $("#option3").text("AABB");
        $("#option4").css("display", "block");
        $("#option4").val("ABBB");
        $("#option4").text("ABBB");
    })


     $('#f1').click(function(){
        $(".fgenome").css("display", "block");
        $("#optionf4").css("display", "none");
        $("#optionf1").val("AA");
        $("#optionf1").text("AA");
        $("#optionf2").val("BB");
        $("#optionf2").text("BB");
        $("#optionf3").val("AB");
        $("#optionf3").text("AB");
    })
    $('#f2').click(function(){
        $(".fgenome").css("display", "block");
        $("#optionf4").css("display", "none");
        $("#optionf1").val("AAA");
        $("#optionf1").text("AAA");
        $("#optionf2").val("AAB");
        $("#optionf2").text("AAB");
        $("#optionf3").val("ABB");
        $("#optionf3").text("ABB");
    })
    $('#f3').click(function(){
        $(".fgenome").css("display", "block");
        $("#optionf1").val("AAAA");
        $("#optionf1").text("AAAA");
        $("#optionf2").val("AAAB");
        $("#optionf2").text("AAAB");
        $("#optionf3").val("AABB");
        $("#optionf3").text("AABB");
        $("#optionf4").css("display", "block");
        $("#optionf4").val("ABBB");
        $("#optionf4").text("ABBB");
    })
 });
</script>


</html>

