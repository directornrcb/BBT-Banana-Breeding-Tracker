
<?php include('server.php') ?>
<?php include('logout.php') ?>
<?php 


  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in to Access that page";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
define('TIMEZONE','Asia/Kolkata');
date_default_timezone_set(TIMEZONE);
$date = date("d-m-Y h:i a",time());
$enabletotal = 0;
$total = 0;
$nhybridtotal = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Results</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- JSpDF -->

    <script type="text/javascript" src="js/excel.js"></script>

    

    <style>
        

.table{
    margin:0;
}
.fa-qrcode{
    font-size: 17px;
    color: #0c6189;
    padding-right: 3px;
}
.fa-trash{
    font-size: 17px;   
}
.fa-user{
    font-size: 21px;
    border: 1px solid;
    border-radius: 20px;
    padding: 2px 4px;
    margin-bottom: 16px;
    margin-right: 9px;
}


</style>

</head>
<body class="home">
    <?php
    if($_GET){

        if(isset($_GET["sort"])){
        include "includes/sort.php";
        }elseif(isset($_GET["fromdate"])){
            $fromdate = sanitize($_GET["fromdate"]);
            $todate = sanitize($_GET["todate"]);
            $c = sanitize($_GET["datec"]);
            $query = "select * from hybridization where $c between '$fromdate' and '$todate' ORDER BY $c";
            $result = $db->query($query);
            $enabletotal = 1;
        }elseif(isset($_GET["delete"])){
            $delete_id = $_GET["id"];
            $db->query("DELETE FROM hybridization WHERE id='$delete_id'");
            header("Location: results.php");
        }
    }
    else{
        $result = $db->query("SELECT * FROM hybridization");

    }

    ?>

    <div class="container-fluid">
    <div class="row">
        
    <div class="col-sm-8">
        <form action="results.php" method="get" class="form-inline">
            <a href="#" data-toggle="dropdown"><i class="fa fa-user" aria-hidden="true"></i></a>
            <ul class="dropdown-menu">
      <li><a href="ch_password.php">Change Password</a></li>
      <li><a href="results.php?logout=1">Log Out</a></li>
    </ul>
            <div class="form-group">
                <div class="input-group date-time" id="datetimepicker">
                    <input class="form-control" name="fromdate"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
            </div>
            <p><i class="fa fa-refresh" aria-hidden="true"></i></p>
            <div class="form-group">
                <div class="input-group date-time" id="datetimepicker2">
                    <input class="form-control" name="todate"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
            </div>
            <div class="form-group mb-auto">
                <select name="datec" id="datec" required="" class="form-control">
                <option value="date">Date of Hybridization</option>
                <option value="dobunchharvest">Date of Bunch harvest</option>
                <option value="doseedextraction">Date of Seed Extraction</option>
                <option value="doseedreceivedatlab">Date of Seed Received at lab</option>
                <option value="doembryoculture">Date of embryo culture</option>
                <option value="dosubculture_shoot">Date of Subculture (Shoot)</option>
                <option value="dosubculture_root">Date of Subculture (Root)</option>
                <option value="doprimaryhardening">Date of primary harderning</option>
                <option value="dateofsecondaryhardening">Date of Secondary hardening</option>
                </select>
            </div>
            <div class="form-group mb-auto">
                <input type="submit" Value="submit" class="form-control btn btn-success ">
                <?php
                if($_GET){
                    echo '<a href="results.php">Clear All Filters</a>';
                }


                ?>
            </div>
        </form>
    </div>
    <button id="btnExport" onclick="javascript:xport.toCSV('mytable','NRCB <?=$date?>');"> Export to CSV</button>
    
        <iframe id="txtArea1" style="display:none"></iframe>

    <div class="col-sm-4 col-xs-8">
      <div class="search-box">
          <input class="form-control" name="search" id="myInput" placeholder="Search..." type="text">
          <button class="btn btn-link search-btn">
            <i class="fa fa-search"></i>
          </button>
      </div>
    </div>
  </div>
        <div class="row ml-of" id="table">
            <table class="table table-hover table-bordered table-striped bigtable" id="mytable">
                <thead>
                    <th class="headcol"><a href="results.php?sort=1&id=<?=((isset($idchange))?$idchange:'1')?>">ID</a></th>
                    <th class="<?=((isset($fnchange))?'bb':'')?>"><a href="results.php?sort=1&fn=<?=((isset($fnchange))?$fnchange:'1')?>">Field Name/Number</a></th>
                    <th class="<?=((isset($pnchange))?'bb':'')?>"><a href="results.php?sort=1&pn=<?=((isset($pnchange))?$pnchange:'1')?>">Plant Number</a></th>
                    <th class="<?=((isset($fpchange))?'bb':'')?>"><a href="results.php?sort=1&fp=<?=((isset($fpchange))?$fpchange:'1')?>">Female Parent</a></th>
                    <th class="<?=((isset($mpchange))?'bb':'')?>"><a href="results.php?sort=1&mp=<?=((isset($mpchange))?$mpchange:'1')?>">Male Parent</a></th>
                    <th class="<?=((isset($nhchange))?'bb':'')?>"><a href="results.php?sort=1&nh=<?=((isset($nhchange))?$nhchange:'1')?>">Number of Hand Hybridized</a></th>
                    <th class="<?=((isset($dhchange))?'bb':'')?>"><a href="results.php?sort=1&dh=<?=((isset($dhchange))?$dhchange:'1')?>">Date of Hybridization</a></th>
                    <th class="<?=((isset($mhchange))?'bb':'')?>"><a href="results.php?sort=1&mh=<?=((isset($mhchange))?$mhchange:'1')?>">Method of Hybridization</a></th>
                    <th class="<?=((isset($techange))?'bb':'')?>"><a href="results.php?sort=1&te=<?=((isset($techange))?$techange:'1')?>">Temperature</a></th>
                    <th class="<?=((isset($huchange))?'bb':'')?>"><a href="results.php?sort=1&hu=<?=((isset($huchange))?$huchange:'1')?>">Humidity</a></th>
                    <th class="<?=((isset($bnchange))?'bb':'')?>"><a href="results.php?sort=1&bn=<?=((isset($bnchange))?$bnchange:'1')?>">Breeder Name</a></th>
                    <th class="<?=((isset($bhchange))?'bb':'')?>"><a href="results.php?sort=1&bh=<?=((isset($bhchange))?$bhchange:'1')?>">Date Of Bunch Harvest</a></th>
                    <th class="<?=((isset($nschange))?'bb':'')?>"><a href="results.php?sort=1&ns=<?=((isset($nschange))?$nschange:'1')?>">No of Seed Extracted</a></th>
                    <th class="<?=((isset($dschange))?'bb':'')?>"><a href="results.php?sort=1&ds=<?=((isset($dschange))?$dschange:'1')?>">Date of Seed Extraction</a></th>
                    <th class="<?=((isset($drchange))?'bb':'')?>"><a href="results.php?sort=1&dr=<?=((isset($drchange))?$drchange:'1')?>">Date of Seed Received at lab</a></th>
                    <th class="<?=((isset($nuchange))?'bb':'')?>"><a href="results.php?sort=1&nu=<?=((isset($nuchange))?$nuchange:'1')?>">Number of Seeds</a></th>
                    <th class="<?=((isset($nsschange))?'bb':'')?>"><a href="results.php?sort=1&nss=<?=((isset($nsschange))?$nsschange:'1')?>">Number of Sunken Seeds</a></th>
                    <th class="<?=((isset($re1change))?'bb':'')?>"><a href="results.php?sort=1&re1=<?=((isset($re1change))?$re1change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($nfschange))?'bb':'')?>"><a href="results.php?sort=1&nfs=<?=((isset($nfschange))?$nfschange:'1')?>">Number of Floating Seeds</a></th>
                    <th class="<?=((isset($re2change))?'bb':'')?>"><a href="results.php?sort=1&re2=<?=((isset($re2change))?$re2change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($nafchange))?'bb':'')?>"><a href="results.php?sort=1&naf=<?=((isset($nafchange))?$nafchange:'1')?>">Number of Seeds After Wash</a></th>
                    <th class="<?=((isset($neichange))?'bb':'')?>"><a href="results.php?sort=1&nei=<?=((isset($neichange))?$neichange:'1')?>">Number of Embryo Initiated</a></th>
                    <th class="<?=((isset($decchange))?'bb':'')?>"><a href="results.php?sort=1&dec=<?=((isset($decchange))?$decchange:'1')?>">Date of Embryo Culture</a></th>
                    <th class="<?=((isset($me1change))?'bb':'')?>"><a href="results.php?sort=1&me1=<?=((isset($me1change))?$me1change:'1')?>">Media</a></th>
                    <th class="<?=((isset($nopchange))?'bb':'')?>"><a href="results.php?sort=1&nop=<?=((isset($nopchange))?$nopchange:'1')?>">Name of Person</a></th>
                    <th class="<?=((isset($ngechange))?'bb':'')?>"><a href="results.php?sort=1&nge=<?=((isset($ngechange))?$ngechange:'1')?>">Number of Germinated Embryo</a></th>
                    <th class="<?=((isset($nipchange))?'bb':'')?>"><a href="results.php?sort=1&nip=<?=((isset($nipchange))?$nipchange:'1')?>">Number of In-Vitro Plants</a></th>
                    <th class="<?=((isset($re3change))?'bb':'')?>"><a href="results.php?sort=1&re3=<?=((isset($re3change))?$re3change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($dsschange))?'bb':'')?>"><a href="results.php?sort=1&dss=<?=((isset($dsschange))?$dsschange:'1')?>">Date of Subculture(Shoot)</a></th>
                    <th class="<?=((isset($re4change))?'bb':'')?>"><a href="results.php?sort=1&re4=<?=((isset($re4change))?$re4change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($me2change))?'bb':'')?>"><a href="results.php?sort=1&me2=<?=((isset($me2change))?$me2change:'1')?>">Media</a></th>
                    <th class="<?=((isset($ng2change))?'bb':'')?>"><a href="results.php?sort=1&ng2=<?=((isset($ng2change))?$ng2change:'1')?>">Number of Germinated Embryo</a></th>
                    <th class="<?=((isset($ni2change))?'bb':'')?>"><a href="results.php?sort=1&ni2=<?=((isset($ni2change))?$ni2change:'1')?>">Number of In-Vitro Plants</a></th>
                    <th class="<?=((isset($re5change))?'bb':'')?>"><a href="results.php?sort=1&re5=<?=((isset($re5change))?$re5change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($dsrchange))?'bb':'')?>"><a href="results.php?sort=1&dsr=<?=((isset($dsrchange))?$dsrchange:'1')?>">Date of Subculture(Root)</a></th>
                    <th class="<?=((isset($re6change))?'bb':'')?>"><a href="results.php?sort=1&re6=<?=((isset($re6change))?$re6change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($me3change))?'bb':'')?>"><a href="results.php?sort=1&me3=<?=((isset($me3change))?$me3change:'1')?>">Media</a></th>
                    <th class="<?=((isset($dopchange))?'bb':'')?>"><a href="results.php?sort=1&dop=<?=((isset($dopchange))?$dopchange:'1')?>">Date of Primary Harderning</a></th>
                    <th class="<?=((isset($no2change))?'bb':'')?>"><a href="results.php?sort=1&no2=<?=((isset($no2change))?$no2change:'1')?>">Number of Plants</a></th>
                    <th class="<?=((isset($remchange))?'bb':'')?>"><a href="results.php?sort=1&rem=<?=((isset($remchange))?$remchange:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($doschange))?'bb':'')?>"><a href="results.php?sort=1&dos=<?=((isset($doschange))?$doschange:'1')?>">Date of Secondary Harderning</a></th>
                    <th class="<?=((isset($no3change))?'bb':'')?>"><a href="results.php?sort=1&no3=<?=((isset($no3change))?$no3change:'1')?>">Number of Plants</a></th>
                    <th class="<?=((isset($re7change))?'bb':'')?>"><a href="results.php?sort=1&re7=<?=((isset($re7change))?$re7change:'1')?>">Remarks</a></th>
                    <th class="<?=((isset($ih1change))?'bb':'')?>"><a href="results.php?sort=1&ih1=<?=((isset($ih1change))?$ih1change:'1')?>">IHIN Code</a></th>
                    <th class="<?=((isset($ih2change))?'bb':'')?>"><a href="results.php?sort=1&ih2=<?=((isset($ih2change))?$ih2change:'1')?>">IHIN Code</a></th>
                    <th class="<?=((isset($qr1change))?'bb':'')?>"><a href="results.php?sort=1&qr1=<?=((isset($qr1change))?$qr1change:'1')?>">QR Code 1</a></th>
                    <th class="<?=((isset($qr2change))?'bb':'')?>"><a href="results.php?sort=1&qr2=<?=((isset($qr2change))?$qr2change:'1')?>">QR Code 2</a></th>
                    <th class="<?=((isset($qr3change))?'bb':'')?>"><a href="results.php?sort=1&qr3=<?=((isset($qr3change))?$qr3change:'1')?>">QR Code 3</a></th>
                    <th class="<?=((isset($qr4change))?'bb':'')?>"><a href="results.php?sort=1&qr4=<?=((isset($qr4change))?$qr4change:'1')?>">QR Code 4</a></th>
                    <th class="<?=((isset($qr5change))?'bb':'')?>"><a href="results.php?sort=1&qr5=<?=((isset($qr5change))?$qr5change:'1')?>">QR Code 5</a></th>
                    <th class="<?=((isset($qr6change))?'bb':'')?>"><a href="results.php?sort=1&qr6=<?=((isset($qr6change))?$qr6change:'1')?>">QR Code 6</a></th>
                    <th class="<?=((isset($qr7change))?'bb':'')?>"><a href="results.php?sort=1&qr7=<?=((isset($qr7change))?$qr7change:'1')?>">QR Code 7</a></th>
                    <th class="<?=((isset($qr8change))?'bb':'')?>"><a href="results.php?sort=1&qr8=<?=((isset($qr8change))?$qr8change:'1')?>">QR Code 8</a></th>
                    <th> </th>
                    
                </thead>
                <tbody id="myTable">
                <?php
                $i = 1;
                while($row = mysqli_fetch_assoc($result)) {
                extract($row);
                ?> 
                    <tr>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> "><?=$id?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Field Name"><?=$name?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Plant Number"><?=$pnumber?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Female Parent"><?=$fparent?>(<?=$fptype?>)</td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Male Parent"><?=$mparent?>(<?=$mptype?>)</td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Hand Hybridized"><?=$nhybrid?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Hybridization"><?=$date?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Method of Hybridization"><?=$mhybrid?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Temperature"><?=$temperature?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Humidity"><?=$humidity?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Breeder Name"><?=$breeder?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Bunch Harverst"><?=$dobunchharvest?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds Extracted"><?=$noseedsextracted?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Seed Extraction"><?=$doseedextraction?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Seed Received at Lab"><?=$doseedreceivedatlab?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds"><?=$noseeds?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Sunken Seeds"><?=$nosunkenseeds?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remark1?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Floating Seeds"><?=$nofloatingseeds?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remark2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds After Wash"><?=$noseedafterwashing?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Embryo Initiated"><?=$noembryoinitiated?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Embryo culture"><?=$doembryoculture?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Name of Person"><?=$nameofperson?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Germinated Embryo"><?=$nogerminatedembryo?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of In-Vitro Plants"><?=$noinvitroplants?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Subculture(Shoot)"><?=$dosubculture_shoot?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks4?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Germinated Embryo"><?=$nogerminatedembryo2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of In-Vitro Plants"><?=$noinvitroplants2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks5?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Subculture(Root)"><?=$dosubculture_root?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks6?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of primary Hardening"><?=$doprimaryhardening?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Plants"><?=$noplants?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remakrs"><?=$remarks?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Secondary Hardening"><?=$dosecondaryhardening?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Plants"><?=$noplants2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks7?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> IHIN Code"><?=$IHIN?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> IHIN Code"><?=$IHIN2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR1"><?=(!empty($qr1))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=1" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr1?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR2"><?=(!empty($qr2))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=2" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR3"><?=(!empty($qr3))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=3" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR4"><?=(!empty($qr4))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=4" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr4?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR5"><?=(!empty($qr5))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=5" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr5?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR6"><?=(!empty($qr6))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=6" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr6?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR6"><?=(!empty($qr7))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=7" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr7?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR7"><?=(!empty($qr8))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=8" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr8?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR8"><a onclick="return confirm('Are you sure want to delete?')" href="results.php?delete=1&id=<?=$id?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                        

                    </tr>
                <?php 
                $i++;
                    if($enabletotal == 1){
                     $total += $id; 
                     $nhybridtotal += $nhybrid;
                    }
                }

                if($enabletotal == 1):
                ?>
                
                <tr>
                    <td><?=$total?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><?=$nhybridtotal?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>

                </tr>
                <?php endif; ?>


                </tbody>           
            </table>          

        </div>
    </div>
    <a id="download" download="myImage.jpg" href="" onclick="download_img(this);">Download to myImage.jpg</a>

</body>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
<script>

function fnExcelReport()
{
    var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
    var textRange; var j=0;
    tab = document.getElementById('#mytable'); // id of table

    for(j = 0 ; j < tab.rows.length ; j++) 
    {     
        tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
        //tab_text=tab_text+"</tr>";
    }

    tab_text=tab_text+"</table>";
    tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
    tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
    tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE "); 

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
    {
        txtArea1.document.open("txt/html","replace");
        txtArea1.document.write(tab_text);
        txtArea1.document.close();
        txtArea1.focus(); 
        sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
    }  
    else                 //other browser not tested on IE 11
        sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

    return (sa);
}
</script>





<script src="js/jquery224.min.js"></script>
<script src="js/bootstrap413.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/datetime.js"></script>
<script  src="js/dp.js"></script>


