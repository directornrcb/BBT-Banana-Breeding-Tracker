<?php


//set it to writable location, a place for temp generated PNG files
$PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
//html PNG location prefix
$PNG_WEB_DIR = 'temp/';


include('./includes/phpqrcode/qrlib.php'); 

    //ofcourse we need rights to create temp dir
if (!file_exists($PNG_TEMP_DIR))
mkdir($PNG_TEMP_DIR);

$filename = $PNG_TEMP_DIR.'NRCB '.$qrname.'.png';

//processing form input
//remember to sanitize user input in real-life solution !!!
$errorCorrectionLevel = 'L';

$matrixPointSize = 4;



QRcode::png($qrcontent, $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
    


//display generated file
echo '<img class="qrimg" src="'.$PNG_WEB_DIR.basename($filename).'" /><hr/>';  
echo '<div class="centered text-center">';
echo '<a class="btn btn-success block" href="'.$PNG_WEB_DIR.basename($filename).'" download><i class="fa fa-download" aria-hidden="true"></i> Download QR</a>';
echo '</div>';



    ?>