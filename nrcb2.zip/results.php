
<?php include('server.php') ?>
<?php include('logout.php') ?>
<?php 

  if (!isset($_SESSION['username'])) {
  	//$_SESSION['msg'] = "You must log in to Access that page";
     // header('location: login.php');
      $not_logged_in = 1;
      
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: results.php");
  }
?>

<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
define('TIMEZONE','Asia/Kolkata');
date_default_timezone_set(TIMEZONE);
$daten = date("d-m-Y h:i a",time());

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Results</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>


    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- JSpDF -->

    <script type="text/javascript" src="js/excel.js"></script>


    <link rel="stylesheet" href="css/style.css">


    

    <style>
        

.table{
    margin:0;
}
.fa-qrcode{
    font-size: 17px;
    color: #0c6189;
    padding-right: 3px;
}
.fa-trash{
    font-size: 17px;   
}
.circle{
    font-size: 21px;
    border: 1px solid;
    border-radius: 20px;
    padding: 2px 4px;
    margin-bottom: 16px;
    margin-right: 9px;
}


</style>

</head>
<body class="home">
    <?php
    if($_GET){

        if(isset($_GET["sort"])){
        include "includes/sort.php";
        }elseif(isset($_GET["fromdate"])){
            $fromdate = sanitize($_GET["fromdate"]);
            $todate = sanitize($_GET["todate"]);
            $c = sanitize($_GET["datec"]);
            $query = "select * from hybridization where $c between '$fromdate' and '$todate' ORDER BY $c";
            $result = $db->query($query);
            $enabletotal = 1;
        }elseif(isset($_GET["delete"])){
            $delete_id = $_GET["id"];
            $db->query("DELETE FROM hybridization WHERE id='$delete_id'");
            header("Location: results.php");
        }elseif(isset($_GET["search"])){
            $search = $_GET["search"];
            $db->query("DELETE FROM hybridization WHERE id='$delete_id'");
            header("Location: results.php");
        }
    }
    else{
        $result = $db->query("SELECT * FROM hybridization");

    }

    ?>

    <div class="container-fluid">
    <div class="row">
        
    <div class="col-sm-10">
        <form action="results.php" method="get" class="form-inline">
            <?=(isset($not_logged_in)?'<a class="brown" href="#" data-toggle="dropdown"><i class="fa fa-user circle" aria-hidden="true"></i></a>
            <ul class="dropdown-menu">
            <li><a class="brown" href="login.php">Log in</a></li>
          </ul>
            ':'
            <a class="brown" href="#" data-toggle="dropdown"><i class="fa fa-user circle" aria-hidden="true"></i></a>
                        <ul class="dropdown-menu">
                        <li><a href="ch_password.php">Change Password</a></li>
                        <li><a href="register.php">Add User</a></li>
                        <li><a href="results.php?logout=1">Log Out</a></li>
                      </ul>
            
            
            ');?>
            <?php $param = "'mytable',";
                    $param2 = "'NRCB $daten'"; ?>
            <?=(isset($not_logged_in)?'':'
                        <a href="#" class="brown export"><i class="fa fa-floppy-o circle" aria-hidden="true"></i></a>

            ');?>


            <div class="form-group">
                <div class="input-group date-time" id="datetimepicker">
                    <input class="form-control" name="fromdate"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
            </div>
            <p><i class="fa fa-refresh " aria-hidden="true"></i></p>
            <div class="form-group">
                <div class="input-group date-time" id="datetimepicker2">
                    <input class="form-control" name="todate"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
            </div>
            <div class="form-group mb-auto">
                <select name="datec" id="datec" required="" class="form-control">
                <option value="date">Date of Hybridization</option>
                <option value="dobunchharvest">Date of Bunch harvest</option>
                <option value="doseedextraction">Date of Seed Extraction</option>
                <option value="doseedreceivedatlab">Date of Seed Received at lab</option>
                <option value="doembryoculture">Date of embryo culture</option>
                <option value="dosubculture_shoot">Date of Subculture (Shoot)</option>
                <option value="dosubculture_root">Date of Subculture (Root)</option>
                <option value="doprimaryhardening">Date of primary harderning</option>
                <option value="dateofsecondaryhardening">Date of Secondary hardening</option>
                </select>
            </div>
            <div class="form-group mb-auto">
                <input type="submit" Value="submit" class="form-control btn btn-result ">

            </div>
            <a href="results.php" class="ml-15" data-html="true" data-toggle="tooltip" title="Refresh"><i class="fa fa-refresh brown fa-spin circle" aria-hidden="true"></i></a>
             
        </form>
    </div>

    <div class="col-sm-2 col-xs-8">

    </div>
  </div>
  <?php
                if($_GET){
                    echo '<a href="results.php">Clear All Filters</a>';
                }
                ?>
        <div class="row ml-of" id="table">
            <table class="table table-hover table-bordered table-striped bigtable tablesorter-custom" id="mytable">
                <thead class="row-bg">
                <tr>
                    <!--to exclude table sorting class="sorter-false" -->
                    <th class="headcol">#</th>
                    <th>ID</th>
                    <th >Field Name/Number</th>
                    <th >Plant Number</th>
                    <th >Female Parent</th>
                    <th>Female Parent Type</a></th>
                    <th>Female Parent Genome</a></th>
                    <th >Male Parent</th>
                    <th>Male Parent Type</a></th>
                    <th>Male Parent Genome</a></th>
                    <th>Number of Hand Hybridized</th>
                    <th>Date of Hybridization</th>
                    <th>Method of Hybridization</th>
                    <th>Temperature</th>
                    <th>Humidity</th>
                    <th>Breeder Name</th>
                    <th>Date Of Bunch Harvest</a></th>
                    <th>No of Seed Extracted</a></th>
                    <th>Date of Seed Extraction</a></th>
                    <th>Date of Seed Received at lab</a></th>
                    <th>Number of Seeds</a></th>
                    <th>Number of Sunken Seeds</a></th>
                    <th>Remarks</a></th>
                    <th>Number of Floating Seeds</a></th>
                    <th>Remarks</a></th>
                    <th>Number of Seeds After Wash</a></th>
                    <th>Number of Embryo Initiated</a></th>
                    <th>Date of Embryo Culture</a></th>
                    <th>Media</a></th>
                    <th>Name of Person</a></th>
                    <th>Number of Germinated Embryo</a></th>
                    <th>Number of In-Vitro Plants</a></th>
                    <th>Remarks</a></th>
                    <th>Date of Subculture(Shoot)</a></th>
                    <th>Remarks</a></th>
                    <th>Media</a></th>
                    <th>Number of Germinated Embryo</a></th>
                    <th>Number of In-Vitro Plants</a></th>
                    <th>Remarks</a></th>
                    <th>Date of Subculture(Root)</a></th>
                    <th>Remarks</a></th>
                    <th>Media</a></th>
                    <th>Date of Primary Harderning</a></th>
                    <th>Number of Plants</a></th>
                    <th>Remarks</a></th>
                    <th>Date of Secondary Harderning</a></th>
                    <th>Number of Plants</a></th>
                    <th>Remarks</a></th>
                    <th>IHIN Code</a></th>
                    <th>IHIN Code</a></th>
                    <th>QR Code 1</a></th>
                    <th>QR Code 2</a></th>
                    <th>QR Code 3</a></th>
                    <th>QR Code 4</a></th>
                    <th>QR Code 5</a></th>
                    <th>QR Code 6</a></th>
                    <th>QR Code 7</a></th>
                    <th>QR Code 8</a></th>
                    <th> </th>
                    </tr>
                    
                </thead>
                
                <tbody id="myTable">
                <?php
                $i = 1;
                while($row = mysqli_fetch_assoc($result)) {
                extract($row);
                ?> 
                    <tr class="tr">
                        <td data-html="true" data-toggle="tooltip" title="Serial Number of ID : <?=$id?> <br> "><?=$i?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> "><?=$id?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Field Name"><?=$name?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Plant Number"><?=$pnumber?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Female Parent"><?=$fparent?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Female Parent Type"><?=$fptype?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Female Parent Genome"><?=$fgenome?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Male Parent"><?=$mparent?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Male Parent Type"><?=$mptype?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Male Parent Genome"><?=$mgenome?></td>
                        <td class="nhybrid" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Hand Hybridized"><?=$nhybrid?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Hybridization"><?=$date?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Method of Hybridization"><?=$mhybrid?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Temperature"><?=$temperature?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Humidity"><?=$humidity?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Breeder Name"><?=$breeder?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Bunch Harverst"><?=$dobunchharvest?></td>
                        <td class="nseeds" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds Extracted"><?=$noseedsextracted?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Seed Extraction"><?=$doseedextraction?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Seed Received at Lab"><?=$doseedreceivedatlab?></td>
                        <td class="noseeds" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds"><?=$noseeds?></td>
                        <td class="nosunkenseeds" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Sunken Seeds"><?=$nosunkenseeds?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remark1?></td>
                        <td class="nofloatingseeds" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Floating Seeds"><?=$nofloatingseeds?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remark2?></td>
                        <td class="noseedsafter" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Seeds After Wash"><?=$noseedafterwashing?></td>
                        <td class="noembryo" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Embryo Initiated"><?=$noembryoinitiated?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Embryo culture"><?=$doembryoculture?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Name of Person"><?=$nameofperson?></td>
                        <td class="nogerminatedembryo" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Germinated Embryo"><?=$nogerminatedembryo?></td>
                        <td class="noinvitroplants" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of In-Vitro Plants"><?=$noinvitroplants?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Subculture(Shoot)"><?=$dosubculture_shoot?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks4?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media2?></td>
                        <td class="nogerminatedembryo2" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Germinated Embryo"><?=$nogerminatedembryo2?></td>
                        <td class="noinvitroplants2" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of In-Vitro Plants"><?=$noinvitroplants2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks5?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Subculture(Root)"><?=$dosubculture_root?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks6?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Media"><?=$media3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of primary Hardening"><?=$doprimaryhardening?></td>
                        <td class="noplants" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Plants"><?=$noplants?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remakrs"><?=$remarks?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Date of Secondary Hardening"><?=$dosecondaryhardening?></td>
                        <td class="noplants2" data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Number of Plants"><?=$noplants2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> Remarks"><?=$remarks7?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> IHIN Code"><?=$IHIN?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> IHIN Code"><?=$IHIN2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR1"><?=(!empty($qr1))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=1" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr1?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR2"><?=(!empty($qr2))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=2" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr2?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR3"><?=(!empty($qr3))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=3" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr3?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR4"><?=(!empty($qr4))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=4" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr4?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR5"><?=(!empty($qr5))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=5" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr5?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR6"><?=(!empty($qr6))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=6" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr6?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR6"><?=(!empty($qr7))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=7" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr7?></td>
                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?> <br> QR7"><?=(!empty($qr8))?'<a href="qrview.php?qr=1&id='.$id.'&qrtype=8" target="_blank"><i class="fa fa-qrcode" aria-hidden="true"></i></a>':''?> <?=$qr8?></td>
                        <!-- Delete Column -->
                        <?php
                        if(!isset($not_logged_in)):?>

                        <td data-html="true" data-toggle="tooltip" title="ID : <?=$id?>"><a onclick="return confirm('Are you sure want to delete?')" href="results.php?delete=1&id=<?=$id?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                        <?php
                        endif;
                        ?>
                        

                    </tr>
                <?php 
                $i++;

                }

               // if($enabletotal == 1):
                ?>
                
                
                <?php //endif; ?>
                <tfoot>
                <tr class="row-bg">

                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th id="nhybridtotal"></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th id="nseedstotal"></th>
                    <th></th>
                    <th></th>
                    <th id="noseedstotal"></th>
                    <th id="nosunkenseeds"></th>
                    <th></th>
                    <th id="nofloatingseeds"></th>
                    <th></th>
                    <th id="noseedsafter"></th>
                    <th id="noembryo"></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th id="nogerminatedembryo"></th>
                    <th id="noinvitroplants"></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th id="nogerminatedembryo2"></th>
                    <th id="noinvitroplants2"></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th id="noplants"></th>
                    <th></th>
                    <th></th>
                    <th id="noplants2"></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></td>

                </tr>
                </tfoot>




                </tbody>           
            </table>        

        </div>
    </div>
 




   
</body>

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
   
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});
</script>
<script>

$(document).ready(function() {

function exportTableToCSV($table, filename) {

    $('.filtered').remove();

     var $rows = $table.find('tr:has(td),tr:has(th)'),

    // Temporary delimiter characters unlikely to be typed by keyboard
    // This is to avoid accidentally splitting the actual contents
    tmpColDelim = String.fromCharCode(11), // vertical tab character
    tmpRowDelim = String.fromCharCode(0), // null character

    // actual delimiter characters for CSV format
    colDelim = '","',
    rowDelim = '"\r\n"',

    // Grab text from table into CSV formatted string
    csv = '"' + $rows.map(function(i, row) {
      var $row = $(row),
        $cols = $row.find('td,th');

      return $cols.map(function(j, col) {
        var $col = $(col),
          text = $col.text();

        return text.replace(/"/g, '""'); // escape double quotes

      }).get().join(tmpColDelim);

    }).get().join(tmpRowDelim)
    .split(tmpRowDelim).join(rowDelim)
    .split(tmpColDelim).join(colDelim) + '"';

  // Deliberate 'false', see comment below
  if (false && window.navigator.msSaveBlob) {

    var blob = new Blob([decodeURIComponent(csv)], {
      type: 'text/csv;charset=utf8'
    });

    // Crashes in IE 10, IE 11 and Microsoft Edge
    // See MS Edge Issue #10396033
    // Hence, the deliberate 'false'
    // This is here just for completeness
    // Remove the 'false' at your own risk
    window.navigator.msSaveBlob(blob, filename);

  } else if (window.Blob && window.URL) {
    // HTML5 Blob        
    var blob = new Blob([csv], {
      type: 'text/csv;charset=utf-8'
    });
    var csvUrl = URL.createObjectURL(blob);

    $(this)
      .attr({
        'download': filename,
        'href': csvUrl
      });
  } else {
    // Data URI
    var csvData = 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);

    $(this)
      .attr({
        'download': filename,
        'href': csvData,
        'target': '_blank'
      });
  }
  location.reload(true);
}

// This must be a hyperlink
$(".export").on('click', function(event) {
  // CSV
  var args = [$('#table>table'), 'NRCB <?=$daten?>.csv'];

  exportTableToCSV.apply(this, args);

  // If CSV, don't do event.preventDefault() or return false
  // We actually need this to be a typical hyperlink
});
});
</script>


<script src='https://mottie.github.io/tablesorter/js/jquery.tablesorter.js'></script>
<script src='https://mottie.github.io/tablesorter/js/jquery.tablesorter.widgets.js'></script>
<script src='https://mottie.github.io/tablesorter/addons/pager/jquery.tablesorter.pager.js'></script>



    <script  src="js/index.js"></script>






<script src="js/jquery224.min.js"></script>
<script src="js/bootstrap413.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/datetime.js"></script>
<script  src="js/dp.js"></script>

<script>
$(document).ready(function() {
    $('.fa-spin').removeClass('fa-spin');
});
</script>



<script>
$(document).ready(function(){  
    $(".tablesorter-filter").focus(function(){  
        $("#nhybridtotal").text(" ");

    });
    $(".tablesorter-filter").blur(function(){  
    
    var sumnhybrid = 0;
    var sumnseeds = 0;
    var noseedstotal = 0;
    var nosunkenseedstotal = 0;
    var nofloatingseedstotal = 0;
    var noseedafterwashing = 0;
    var noembryoinitiatedtotal = 0;
    var nogerminatedembryototal = 0;
    var noinvitroplantstotal = 0;
    var nogerminatedembryo2total = 0;
    var noinvitroplants2total = 0;
    var noplantstotal = 0;
    var noplants2total = 0;
    $(".tr").each(function(){
    if(!$(this).hasClass("filtered")){

    sumnhybrid += Number($(this).children('td.nhybrid').text());

    $("#nhybridtotal").text("Total : "+sumnhybrid);



    sumnseeds += Number($(this).children('td.nseeds').text());

    $("#nseedstotal").text("Total : "+sumnseeds); 
    
    noseedstotal += Number($(this).children('td.noseeds').text());

    $("#noseedstotal").text("Total : "+noseedstotal); 
        
        
    nosunkenseedstotal += Number($(this).children('td.nosunkenseeds').text());

    $("#nosunkenseeds").text("Total : "+nosunkenseedstotal); 
            
    noseedafterwashing += Number($(this).children('td.noseedsafter').text());

    $("#noseedsafter").text("Total : "+noseedafterwashing); 
            
    noembryoinitiatedtotal += Number($(this).children('td.noembryo').text());

    $("#noembryo").text("Total : "+noembryoinitiatedtotal); 
                
    nogerminatedembryototal += Number($(this).children('td.nogerminatedembryo').text());

    $("#nogerminatedembryo").text("Total : "+nogerminatedembryototal); 
                    
    noinvitroplantstotal += Number($(this).children('td.noinvitroplants').text());

    $("#noinvitroplants").text("Total : "+noinvitroplantstotal); 

                    
    nogerminatedembryo2total += Number($(this).children('td.nogerminatedembryo2').text());

    $("#nogerminatedembryo2").text("Total : "+nogerminatedembryo2total); 


    noinvitroplants2total += Number($(this).children('td.noinvitroplants2').text());

    $("#noinvitroplants2").text("Total : "+noinvitroplants2total); 
    

    noplantstotal += Number($(this).children('td.noplants').text());

    $("#noplants").text("Total : "+noplantstotal); 

    noplants2total += Number($(this).children('td.noplants2').text());

    $("#noplants2").text("Total : "+noplants2total); 




    
    
    
    };

});
});
});
</script>

