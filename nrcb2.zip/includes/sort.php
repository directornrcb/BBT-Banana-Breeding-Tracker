
<?php
if(isset($_GET["id"])){
            if($_GET["id"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`id` DESC");
            $idchange = 2;
            }elseif ($_GET["id"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `id`");
                $idchange = 1;
            }
        }
        if(isset($_GET["fn"])){
            if($_GET["fn"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`name` DESC");
            $fnchange = 2;
            }elseif ($_GET["fn"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `name`");
                $fnchange = 1;
            }
           
        }
        if(isset($_GET["pn"])){
            if($_GET["pn"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`pnumber` DESC");
            $pnchange = 2;
            }elseif ($_GET["pn"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `pnumber`");
                $pnchange = 1;
            }
           
        }
        if(isset($_GET["fp"])){
            if($_GET["fp"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`fparent` DESC");
            $fpchange = 2;
            }elseif ($_GET["fp"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `fparent`");
                $fpchange = 1;
            }
           
        }
        if(isset($_GET["fpt"])){
            if($_GET["fpt"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`fptype` DESC");
            $fptchange = 2;
            }elseif ($_GET["fpt"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `fptype`");
                $fptchange = 1;
            }
           
        }
        if(isset($_GET["fpg"])){
            if($_GET["fpg"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`fgenome` DESC");
            $fpgchange = 2;
            }elseif ($_GET["fpg"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `fgenome`");
                $fpgchange = 1;
            }
           
        }
        if(isset($_GET["mp"])){
            if($_GET["mp"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`mparent` DESC");
            $mpchange = 2;
            }elseif ($_GET["mp"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `mparent`");
                $mpchange = 1;
            }
           
        }
        if(isset($_GET["mpt"])){
            if($_GET["mpt"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`mptype` DESC");
            $mptchange = 2;
            }elseif ($_GET["mpt"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `mptype`");
                $mptchange = 1;
            }
           
        }
        if(isset($_GET["mpg"])){
            if($_GET["mpg"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`mgenome` DESC");
            $mpgchange = 2;
            }elseif ($_GET["mpg"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `mgenome`");
                $mpgchange = 1;
            }
           
        }
        if(isset($_GET["nh"])){
            if($_GET["nh"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`nhybrid` DESC");
            $nhchange = 2;
            }elseif ($_GET["nh"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `nhybrid`");
                $nhchange = 1;
            }
           
        }
        if(isset($_GET["dh"])){
            if($_GET["dh"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`date` DESC");
            $dhchange = 2;
            }elseif ($_GET["dh"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `date`");
                $dhchange = 1;
            }
           
        }
        if(isset($_GET["mh"])){
            if($_GET["mh"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`mhybrid` DESC");
            $mhchange = 2;
            }elseif ($_GET["mh"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `mhybrid`");
                $mhchange = 1;
            }
           
        }
        if(isset($_GET["te"])){
            if($_GET["te"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`temperature` DESC");
            $techange = 2;
            }elseif ($_GET["te"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `temperature`");
                $techange = 1;
            }
           
        }
        if(isset($_GET["hu"])){
            if($_GET["hu"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`humidity` DESC");
            $huchange = 2;
            }elseif ($_GET["hu"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `humidity`");
                $huchange = 1;
            }
           
        }
        if(isset($_GET["bn"])){
            if($_GET["bn"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`breeder` DESC");
            $bnchange = 2;
            }elseif ($_GET["bn"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `breeder`");
                $bnchange = 1;
            }
           
        }
        if(isset($_GET["bh"])){
            if($_GET["bh"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`dobunchharvest` DESC");
            $bhchange = 2;
            }elseif ($_GET["bh"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `dobunchharvest`");
                $bhchange = 1;
            }
           
        }
        if(isset($_GET["ns"])){
            if($_GET["ns"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseedsextracted` DESC");
            $nschange = 2;
            }elseif ($_GET["ns"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseedsextracted`");
                $nschange = 1;
            }
           
        }
        if(isset($_GET["ds"])){
            if($_GET["ds"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`doseedextraction` DESC");
            $dschange = 2;
            }elseif ($_GET["ds"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `doseedextraction`");
                $dschange = 1;
            }
           
        }
        if(isset($_GET["dr"])){
            if($_GET["dr"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`doseedreceivedatlab` DESC");
            $drchange = 2;
            }elseif ($_GET["dr"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `doseedreceivedatlab`");
                $drchange = 1;
            }
           
        }
        if(isset($_GET["nu"])){
            if($_GET["nu"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nuchange = 2;
            }elseif ($_GET["nu"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nuchange = 1;
            }
           
        }
        if(isset($_GET["nu"])){
            if($_GET["nu"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nuchange = 2;
            }elseif ($_GET["nu"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nuchange = 1;
            }
           
        }
        if(isset($_GET["nss"])){
            if($_GET["nss"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nsschange = 2;
            }elseif ($_GET["nss"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nsschange = 1;
            }
           
        }
        if(isset($_GET["re1"])){
            if($_GET["re1"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re1change = 2;
            }elseif ($_GET["re1"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re1change = 1;
            }
           
        }
        if(isset($_GET["nfs"])){
            if($_GET["nfs"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nfschange = 2;
            }elseif ($_GET["nfs"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nfschange = 1;
            }
           
        }
        if(isset($_GET["re2"])){
            if($_GET["re2"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re2change = 2;
            }elseif ($_GET["re2"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re2change = 1;
            }
           
        }
        if(isset($_GET["naf"])){
            if($_GET["naf"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nafchange = 2;
            }elseif ($_GET["naf"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nafchange = 1;
            }
           
        }
        if(isset($_GET["nei"])){
            if($_GET["nei"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $neichange = 2;
            }elseif ($_GET["nei"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $neichange = 1;
            }
           
        }
        if(isset($_GET["dec"])){
            if($_GET["dec"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $decchange = 2;
            }elseif ($_GET["dec"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $decchange = 1;
            }
           
        }
        if(isset($_GET["me1"])){
            if($_GET["me1"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $me1change = 2;
            }elseif ($_GET["me1"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $me1change = 1;
            }
           
        }
        if(isset($_GET["nop"])){
            if($_GET["nop"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nopchange = 2;
            }elseif ($_GET["nop"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nopchange = 1;
            }
           
        }
        if(isset($_GET["nge"])){
            if($_GET["nge"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $ngechange = 2;
            }elseif ($_GET["nge"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $ngechange = 1;
            }
           
        }
        if(isset($_GET["nip"])){
            if($_GET["nip"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $nipchange = 2;
            }elseif ($_GET["nip"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $nipchange = 1;
            }
           
        }
        if(isset($_GET["re3"])){
            if($_GET["re3"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re3change = 2;
            }elseif ($_GET["re3"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re3change = 1;
            }
           
        }
        if(isset($_GET["dss"])){
            if($_GET["dss"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $dsschange = 2;
            }elseif ($_GET["dss"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $dsschange = 1;
            }
           
        }
        if(isset($_GET["re4"])){
            if($_GET["re4"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re4change = 2;
            }elseif ($_GET["re4"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re4change = 1;
            }
           
        }
        if(isset($_GET["me2"])){
            if($_GET["me2"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $me2change = 2;
            }elseif ($_GET["me2"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $me2change = 1;
            }
           
        }
        if(isset($_GET["ni2"])){
            if($_GET["ni2"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $ni2change = 2;
            }elseif ($_GET["ni2"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $ni2change = 1;
            }
           
        }
        if(isset($_GET["re5"])){
            if($_GET["re5"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re5change = 2;
            }elseif ($_GET["re5"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re5change = 1;
            }
           
        }
        if(isset($_GET["dsr"])){
            if($_GET["dsr"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $dsrchange = 2;
            }elseif ($_GET["dsr"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $dsrchange = 1;
            }
           
        }
        if(isset($_GET["re6"])){
            if($_GET["re6"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re6change = 2;
            }elseif ($_GET["re6"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re6change = 1;
            }
           
        }
        if(isset($_GET["me3"])){
            if($_GET["me3"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $me3change = 2;
            }elseif ($_GET["me3"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $me3change = 1;
            }
           
        }
        if(isset($_GET["dop"])){
            if($_GET["dop"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $dopchange = 2;
            }elseif ($_GET["dop"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $dopchange = 1;
            }
           
        }
        if(isset($_GET["no2"])){
            if($_GET["no2"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $no2change = 2;
            }elseif ($_GET["no2"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $no2change = 1;
            }
           
        }
        if(isset($_GET["rem"])){
            if($_GET["rem"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $remchange = 2;
            }elseif ($_GET["rem"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $remchange = 1;
            }
           
        }
        if(isset($_GET["dos"])){
            if($_GET["dos"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $doschange = 2;
            }elseif ($_GET["dos"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $doschange = 1;
            }
           
        }
        if(isset($_GET["no3"])){
            if($_GET["no3"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $no3change = 2;
            }elseif ($_GET["no3"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $no3change = 1;
            }
           
        }
        if(isset($_GET["re7"])){
            if($_GET["re7"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $re7change = 2;
            }elseif ($_GET["re7"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $re7change = 1;
            }
           
        }
        if(isset($_GET["ih1"])){
            if($_GET["ih1"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $ih1change = 2;
            }elseif ($_GET["ih1"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $ih1change = 1;
            }
           
        }
        if(isset($_GET["ih2"])){
            if($_GET["ih2"] == 1){
            $result = $db->query("SELECT * FROM `hybridization` ORDER BY `hybridization`.`noseeds` DESC");
            $ih2change = 2;
            }elseif ($_GET["ih2"] == 2){
                $result = $db->query("SELECT * FROM `hybridization` ORDER BY `noseeds`");
                $ih2change = 1;
            }
           
        }




        ?>

        