<?php

require_once "core/init.php";
include "core/helpers.php";
$errors = array();

if($_GET){
    if(isset($_GET["qr"])){
        $id = $_GET["id"];
        $result = $db->query("SELECT * FROM hybridization WHERE id='$id'");
        $results = mysqli_fetch_assoc($result);
        extract($results);

        if($_GET["qrtype"] == 1){
            $qrt = "ID : $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Number of Hand Hybridized : $nhybrid <br>Method of Hybridization : $mhybrid  <br>Date of Hybridization : $date <br>Temperature : $temperature <br>Humidity : $humidity <br>Breeder : $breeder";
            $qr = "ID : $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nNumber of Hand Hybridized : $nhybrid \nMethod of Hybridization : $mhybrid  \nDate of Hybridization : $date \nTemperature : $temperature \nHumidity : $humidity \nBreeder : $breeder";

        }
        if($_GET["qrtype"] == 2){
            $qrt = " ID: $id <br> Field Name : $name <br> Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br> Male Parent : $mparent<br>Male Parent Genome : $mgenome <br> Date of Crossing : $date <br> Date of Bunch Harvested : $dobunchharvest <br> Date of Seed Extration : $doseedextraction <br> Total Number of Seeds : $noseedsextracted";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nDate of Crossing : $date \nDate of Bunch Harvested : $dobunchharvest \nDate of Seed Extration : $doseedextraction \nTotal Number of Seeds : $noseedsextracted";

        }
        if($_GET["qrtype"] == 3){
            $qrt = "ID: $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Total Number of Seeds : $noseeds <br>Date of Seed Receiving at lab : $doseedreceivedatlab <br>Date of embryo culture : $doembryoculture ";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nTotal Number of Seeds : $noseeds \nDate of Seed Receiving at lab : $doseedreceivedatlab \nDate of embryo culture : $doembryoculture ";
        }
        if($_GET["qrtype"] == 4){
            $qrt = "ID: $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Date of Embryo culture : $doembryoculture <br>Date of Sub Culturing : $dosubculture_shoot";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nDate of Embryo culture : $doembryoculture \nDate of Sub Culturing : $dosubculture_shoot";
        }
        if($_GET["qrtype"] == 5){
            $qrt = "ID: $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Date of Embryo culture : $doembryoculture <br>Date of Sub Culturing (Root) : $dosubculture_root";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nDate of Embryo culture : $doembryoculture \nDate of Sub Culturing (Root) : $dosubculture_root";
        }
        if($_GET["qrtype"] == 6){
            $qrt = "ID: $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Date of Embryo Culture : $doembryoculture <br>Date of Sub Culture (Shoot) : $dosubculture_shoot <br>Date of Sub Culture (Root) : $dosubculture_root <br>Date of Primary Hardering : $doprimaryhardening";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nDate of Embryo Culture : $doembryoculture \nDate of Sub Culture (Shoot) : $dosubculture_shoot \nDate of Sub Culture (Root) : $dosubculture_root \nDate of Primary Hardering : $doprimaryhardening";
        }
        if($_GET["qrtype"] == 7){
            $qrt = "ID: $id <br>Field Name : $name <br>Plant Number : $pnumber <br>Female Parent : $fparent <br>Female Parent Genome : $fgenome <br>Male Parent : $mparent <br>Male Parent Genome : $mgenome <br>Date of Primary Hardening : $doprimaryhardening <br>Date of Secondary Harderning : $dosecondaryhardening <br>IHIN Code : $IHIN";
            $qr = "ID: $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent : $fparent \nFemale Parent Genome : $fgenome \nMale Parent : $mparent \nMale Parent Genome : $mgenome \nDate of Primary Hardening : $doprimaryhardening \nDate of Secondary Harderning : $dosecondaryhardening \nIHIN Code : $IHIN";
        }
        if($_GET["qrtype"] == 8){
            $qrt = "ID: $id <br>IHIN Code : $IHIN2";
            $qr = "ID: $id \nIHIN Code : $IHIN2";
        }



    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>View QR</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

<div class="container-fluid">
<hr>
    <div class="row">
        <div class="col-md-6">
        <p class="text-center">QR Code:</p>
        <?php 
            $qrcontent = $qr;
            $qrcontent = stripslashes($qrcontent);
            $qrname = "View QR";
            
            include "qr.php";
        ?>
        </div>
        <div class="col-md-6">
        <p class="text-center">QR Details:</p>
        <p><?=$qrt?></p>
        </div>
        
    </div>
</div>
</body>
<?php
}
?>