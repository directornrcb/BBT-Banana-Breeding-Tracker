<?php
require_once "core/init.php";
include "core/helpers.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sub Culture (Root)</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="css/bootstrap337.css">

    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>

    <div class="container">
        <div class="row">
        <hr>
            <div class="col-md-8 col-md-offset-2 form-shadow">
                <h3 class="text-center">Sub Culture (Root)</h3>
                <form action="form5b.php" method="get">
                <div class="form-group">
                <label for="id">ID Number*</label>
                <input type="text" name="id" placeholder="Enter ID Number" required class="form-control">
                </div>
                <div class="form-group">
                <label for="nogermin">Number of Germinated Embryo*</label>
                <input type="text" name="nogermin" placeholder="Enter the number of Germinated Embryo" required class="form-control">
                </div>
                <div class="form-group">
                <label for="noinvitro">Number of In-Vitro Plants*</label>
                <input type="text" name="noinvitro" placeholder="Enter Number of In-Vitro Plants" required class="form-control">
                </div>
                <div class="form-group">
                <label for="remark1">Remarks</label>
                <input type="text" name="remark1" placeholder="Remarks"  class="form-control">
                </div>
                <div class="form-group">
                <label for="date">Date of Subculture (Root)*</label>
                <div class="input-group date-time" id="datetimepicker">
                <input class="form-control" name="date"/><span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                </div>
                </div>
                <div class="form-group">
                <label for="remark2">Remarks</label>
                <input type="text" name="remark2" placeholder="Remarks" class="form-control">
                </div>
                <div class="form-group">
                <label for="media">Media*</label>
                <input type="text" name="media" placeholder="Media" required class="form-control">
                </div>
                <div class="form-group">
                <a href="index.php" class="float-left btn btn-info btn-lg "><i class="fa fa-chevron-left" aria-hidden="true"></i> Back</a>
                <input type="submit" Value="Submit" class="float-right btn btn-success btn-lg mb-7">
                </div>


                </form>
            </div>      
        </div>
    </div>
    <footer>
    
    <p class="text-center">NRCB</p>
    </footer>
</body>

    <!-- jQuery library -->
   <!--  <script src="js/jquery.js"></script> -->

<script src="js/jquery224.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/datetime.js"></script>
<script  src="js/dp.js"></script>



</html>

