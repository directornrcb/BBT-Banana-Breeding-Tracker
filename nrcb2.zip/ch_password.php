
<?php include('server.php') ?>
<?php include('logout.php') ?>
<?php 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html>
<html>
<head>

	
	
	<title>Change Password</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

	<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet'>

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

	<style>
	@media screen and (min-width: 600px){
#login-form {
		width: 49%;
    height: auto;
    border: 2px solid lightgrey;
    box-shadow: 7px 7px 15px rgba(0,0,0,0.6);
    margin: 5% auto;
    padding: 15px;
    background: #e0f7fa36;
}
}
.text-success{
	color:#28a745!important
}
	</style>
</head>
<body>

 
	<div class="container">
    <div class="row" id="login-form">
        <div class="col-md-12">
        <h2 class="text-center"><i class="fas fa-lock text-success"> </i> Change Password</h2>
            <form action="ch_password.php" method="post">
                <div class="text-danger">
                        <?php include('errors.php'); ?>
                        </div>
            <div class="form-group">
                <label for="current">Current Password</label>
                <input type="password" class="form-control" name="current" placeholder="Enter Current Password" value="">
            </div>
            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" value="">
            </div>
            <div class="form-group">
                <label for="confirm">Confirm Password</label>
                <input type="password" class="form-control" name="confirm" placeholder="Confirm Password" value="">
            </div>
            <div class="col-md-6">
            <button type="submit" name="ch_password" class="btn btn-success width-100 mb-20">Update Password</button>
            </div>
            <div class="col-md-6">
            <a href="results.php" class="btn btn-info float-right">Cancel</a>
            </div>
            </form>
        </div>
      
    </div>
</div>
</body>
</html>