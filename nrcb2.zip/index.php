


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home | NRCB</title>


    <!-- date and timepicker -->
    <link rel='stylesheet' href='css/select2.css'>
    <!-- fontawesome -->
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/dp.css">
    
    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">




    

    <style>
    h3{
        font-size:19px!important;
        font-family: muli;
    }
    </style>

</head>
<body class="home padding-0" >
    <div class="container-fluid head" style="padding:0px;">
    <div class="row margin-0">
    <div class="col-md-12 padding-0">
        <a class="w--current" href="index.php">
        <img src="img/head.png" class="width-100" alt="Logo">
        </a>
        
    </div>
    </div>
    </div>

   

    <div class="container " style="padding:0px;">
    <nav class="navbar navbar-expand-lg navbar-light bg-light justify-content-center">
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto text-center centered bold">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="bbt.php">BBtbase</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact Us</a>
      </li>
    </ul>

  </div>
</nav>

<section style="padding-top:10px;">
<div class="row text-container">
<h3 class="text-center title">Banana Breeding Tracker Database (BBT)</h3>
<p class="text-justify">A Banana Breeding Tracker Database (BBTbase) is a web-based software office suite/Database that works on all operating systems, has been developed. The BBTbase allows any number of users to enter their breeding information at the same time.  All the users can monitor the progress of the banana breeding program and retrieve the information. This database can be used to develop quick responsive code (QR code) for labelling which can be decoded using a QR scanner.  At every stage of hybrid development, the information will be updated and new QR code will be generated to avoid mislabeling.  Thus, the BBTbase QR code will be the most useful tool in the maintenance of breeding information. The BBTbase has been developed and being implemented at ICAR-NRCB to monitor banana breeding program</p>
</div>
</section>

        <div class="row">
        <div class="col-md-3">
        <div class="items">
        <a href="form1a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Hybridization</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form2a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Seed Extraction</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form3a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Embryo Culture</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form4a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Sub Culture (Shoot)</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form5a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Sub Culture (Root)</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form6a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Primary Hardening</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form7a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">Secondary Hardening</h3>
        </div>
        </div>
        <div class="col-md-3">
        <div class="items">
        <a href="form8a.php"><span class="link"></span></a>
        <img src="img/banana.svg" width="100px" class="centered" alt="">
        <h3 class="text-center">IHIN</h3>
        </div>
        </div>
        </div>
    </div>
<!-- Footer -->
<section></section>
<div class="footer-copyright text-center py-3 " style="
    background: #673ab785;">© 2018 Copyright:
      <a style="color:white;" href="http://nrcb.res.in/">ICAR- National Research Centre for Banana. All Rights Reserved.</a>
    </div>

</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script>

$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

     //>=, not <=
    if (scroll >= 280) {
        //clearHeader, not clearheader - caps H
        $(".navbar").addClass("fixed-top");
    }
    if (scroll < 280) {
        //clearHeader, not clearheader - caps H
        $(".navbar").removeClass("fixed-top");
    }
}); 
</script>
</html>
