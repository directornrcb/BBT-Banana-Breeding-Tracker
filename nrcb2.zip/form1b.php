<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form 1</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

</head>
<body>
<?php
if($_POST){
    $name = $_POST['name'];
    $pnumber = $_POST['pnumber'];
    $fparent = $_POST['fparent'];
    $ftype = $_POST['ftype'];
    $mparent = $_POST['mparent'];
    $mtype = $_POST['mtype'];
    $nhybrid = $_POST['nhybrid'];
    $date = $_POST['date'];
    $mhybrid = $_POST['mhybrid'];
    $temperature = $_POST['temperature'];
    $humidity = $_POST['humidity'];
    $mhybrido = $_POST['others'];
    $breeder = $_POST['breeder'];
    $fgenome = $_POST['fgenome'];
    $mgenome = $_POST['mgenome'];

    if($mhybrid == "Others"){
        $mhybrid = $mhybrido;
    }
    if(!empty($errors)){
        echo display_errors($errors);
    }else{
        $query = "INSERT INTO hybridization (name,pnumber,fparent,mparent,nhybrid,mhybrid,temperature,humidity,breeder,date,fptype,mptype,fgenome,mgenome) VALUES ('$name','$pnumber','$fparent','$mparent','$nhybrid','$mhybrid','$temperature','$humidity','$breeder','$date','$ftype','$mtype','$fgenome','$mgenome')";
        //echo $query;
        $db->query($query);
        
        $id = mysqli_insert_id($db);

        $qr1 = "ID : $id Field Name : $name Plant Number : $pnumber Female Parent : $fparent Female parent type: $ftype Female Parent Genome : $fgenome Male Parent : $mparent Male Parent Type : $mtype Male Parent Genome : $mgenome Number of Hand Hybridized : $nhybrid Method of Hybridization : $mhybrid  Date of Hybridization : $date Temperature : $temperature Humidity : $humidity Breeder : $breeder";
        $db->query("UPDATE hybridization SET qr1='$qr1' WHERE id='$id'");
        ?>
        <h3 class="text-center text-success mb-20">Updated Successfully</h3>
        <hr>
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-6">
    <p class="text-center">QR Code:</p>
        <?php 
            $qrcontent = "ID : $id \nField Name : $name \nPlant Number : $pnumber \nFemale Parent: $fparent \nFemale Parent Type: $ftype \nFemale Parent Genome: $fgenome \nMale Parent : $mparent \nMale Parent Type: $mtype \nMale Parent Genome: $mgenome \nNumber of Hand Hybridized : $nhybrid \nDate of Hybridization : $date \nMethod of Hybridization : $mhybrid \nTemperature : $temperature \nHumidity : $humidity \nBreeder : $breeder";
            $qrcontent = stripslashes($qrcontent);
            $qrname = "QR1";
            
            include "qr.php";
        ?>
    </div>
    <div class="col-md-6">
    <table class="table table-hover table-bordered table-condensed table-striped ">
    <thead>
    <th>Title</th>
    <th>Values</th>
    </thead>
    <tr>
        <td>ID</td>
        <td><?=$id?></td>
    </tr>
    <tr>
        <td>Field Name</td>
        <td><?=$name?></td>
    </tr>
    <tr>
        <td>Plant Number</td>
        <td><?=$pnumber?></td>
    </tr>
    <tr>
        <td>Female parent</td>
        <td><?=$fparent?></td>
    </tr>
    <tr>
        <td>Female parent Type</td>
        <td><?=$ftype?></td>
    </tr>
    <tr>
        <td>Female parent Genome</td>
        <td><?=$fgenome?></td>
    </tr>
    <tr>
        <td>Male Parent</td>
        <td><?=$mparent?></td>
    </tr>
    <tr>
        <td>Male parent Genome</td>
        <td><?=$mgenome?></td>
    </tr>
    <tr>
        <td>Male parent Type</td>
        <td><?=$mtype?></td>
    </tr>
    <tr>
        <td>Number of hand hybrid</td>
        <td><?=$nhybrid?></td>
    </tr>
    <tr>
        <td>Method of Hybridization</td>
        <td><?=$mhybrid?></td>
    </tr>
    <tr>
        <td>Date of Hybridization</td>
        <td><?=$date?></td>
    </tr>
    <tr>
        <td>Temperature</td>
        <td><?=$temperature?></td>
    </tr>
    <tr>
        <td>Humidity</td>
        <td><?=$humidity?></td>
    </tr>
    <tr>
        <td>Breeder</td>
        <td><?=$breeder?></td>
    </tr>

    </table>
    </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-2 col-md-offset-5">
          <a href="form1a.php" class="btn btn-info centered">Make Another Submission!</a>
        </div>
    </div>

        <?php
    }

}
if($_GET){
?>

 <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 mt-30">
            <h3 class="text-center">Make Sure Your Inputs are correct!</h3>
            <form action="form1b.php" method="post">
            <table class="table table-bordered table-hover table-striped">
           

                <tr>
                    <td>Field Name / Number</td>
                    <td><?=$_GET["name"]?><input type="hidden" name="name" value="<?=$_GET["name"]?>"></td>
                </tr>
                <tr>
                    <td>Plant Number</td>
                    <td><?=$_GET["pnumber"]?><input type="hidden" name="pnumber" value="<?=$_GET["pnumber"]?>"></td>
                </tr>
                <tr>
                    <td>Female Parent</td>
                    <td><?=$_GET["fparent"]?><input type="hidden" name="fparent" value="<?=$_GET["fparent"]?>"></td>
                </tr>
                <tr>
                    <td>Female Parent Type</td>
                    <td><?=$_GET["ftype"]?><input type="hidden" name="ftype" value="<?=$_GET["ftype"]?>"></td>
                </tr>
                <tr>
                    <td>Female Parent Genome</td>
                    <td><?=$_GET["fgenome"]?><input type="hidden" name="fgenome" value="<?=$_GET["fgenome"]?>"></td>
                </tr>
                <tr>
                    <td>Male Parent</td>
                    <td><?=$_GET["mparent"]?><input type="hidden" name="mparent" value="<?=$_GET["mparent"]?>"></td>
                </tr>
                <tr>
                    <td>Male Parent Type</td>
                    <td><?=$_GET["mtype"]?><input type="hidden" name="mtype" value="<?=$_GET["mtype"]?>"></td>
                </tr>
                <tr>
                    <td>Male Parent Genome</td>
                    <td><?=$_GET["mgenome"]?><input type="hidden" name="mgenome" value="<?=$_GET["mgenome"]?>"></td>
                </tr>
                <tr>
                    <td>Number of Hand Hybrid</td>
                    <td><?=$_GET["nhybrid"]?><input type="hidden" name="nhybrid" value="<?=$_GET["nhybrid"]?>"></td>
                </tr>
                <tr>
                    <td>Date of Hybridization</td>
                    <td><?=$_GET["date"]?><input type="hidden" name="date" value="<?=$_GET["date"]?>"></td>
                </tr>
                <tr>
                    <td>Method of Hybridization</td>
                    <td><?=$_GET["mhybrid"]?><input type="hidden" name="mhybrid" value="<?=$_GET["mhybrid"]?>"></td>
                </tr>

                <input type="hidden" name="others" value="<?=$_GET["others"]?>">
                <?php if($_GET["mhybrid"] == "Others"):?>

                <tr>
                    <td>Others</td>
                    <td><?=$_GET["others"]?><input type="hidden" name="others" value="<?=$_GET["others"]?>"></td>
                </tr>

                <?php endif;?>
                
                <tr>
                    <td>Temperature</td>
                    <td><?=$_GET["temperature"]?><input type="hidden" name="temperature" value="<?=$_GET["temperature"]?>"></td>
                </tr>
                <tr>
                    <td>Humidity</td>
                    <td><?=$_GET["humidity"]?><input type="hidden" name="humidity" value="<?=$_GET["humidity"]?>"></td>
                </tr>
                <tr>
                    <td>Name of the Breeder</td>
                    <td><?=$_GET["breeder"]?><input type="hidden" name="breeder" value="<?=$_GET["breeder"]?>"></td>
                </tr>
                
            </table>
                <div class="col-md-6 col-md-offset-3">
                    <div class="col-md-4 col-sm-4 col-xs-4"><input type="submit" class="btn btn-success" value="Correct"></div>
                    <div class="col-md-4 col-sm-4 col-xs-4"> <a href="form1a.php" class="btn btn-info">Re-Enter</a></div>
                </div>
            </form>

            </div>
        </div>
    </div>
    </div>
<?php

}

?>



<script type="text/javascript">
function disableF5(e) { if ((e.which || e.keyCode) == 116 || (e.which || e.keyCode) == 82) e.preventDefault(); };

$(document).ready(function(){
     $(document).on("keydown", disableF5);
});
</script>

</body>