<?php
require_once "core/init.php";
include "core/helpers.php";
$errors = array();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form 8</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <!-- CSS -->
    <link rel="stylesheet" href="style.css">

    <!-- Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>
<?php
if($_POST){
    $id = $_POST['id'];
    $ihin = $_POST['ihin'];

    $result = $db->query("SELECT * FROM hybridization WHERE id = $id");
    $num_rows = mysqli_num_rows($result);

    if($num_rows == 0){
        echo '<h3 class="text-center text-danger">Invalid ID given</h3>';
        $errors = 'No Row found';
        echo '<div class="text-center"><a href="form8a.php" class="text-info text-center">Try Again!</a></div>';
        die();
    }
   
    if(!empty($errors)){
        echo display_errors($errors);
    }else{
        
        $query = "UPDATE hybridization SET IHIN2 = '$ihin' WHERE id = '$id' ";
       // echo $query;
        $db->query($query);
        
        $query = "SELECT * FROM hybridization WHERE id = $id";
        $results =  $db->query($query);
        $results = mysqli_fetch_assoc($results);




        $qr8 = "ID: $id IHIN Code : $ihin";

        $db->query("UPDATE hybridization SET qr8='$qr8' WHERE id='$id'");
        ?>
        <h3 class="text-center text-success mb-20">Updated Successfully</h3>
    <hr>
    <div class="container-fluid">
    <div class="row">
    <div class="col-md-6">
    <p class="text-center">QR Code:</p>
    <?php 
            $qrcontent = "ID: $id \nIHIN Code : $ihin";
            $qrcontent = stripslashes($qrcontent);
            $qrname = "QR8";
            
            include "qr.php";
    ?>
    </div>
    <div class="col-md-6">
        <h4 class="text-center">Updated Details</h4>
    <table class="table table-hover table-bordered table-condensed table-striped ">
    <thead>
    <th>Title</th>
    <th>Values</th>
    </thead>
    <tr>
        <td>ID</td>
        <td><?=$id?></td>
    </tr>
    <tr>
        <td>IHIN Code</td>
        <td><?=$ihin?></td>
    </tr>


    

    </table>
    </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-2 col-md-offset-5">
          <a href="form8a.php" class="btn btn-info centered">Make Another Submission!</a>
        </div>
    </div>

        <?php
    }

}
if($_GET){
?>

 <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3 mt-30">
            <h3 class="text-center">Make Sure Your Inputs are correct!</h3>
            <form action="form8b.php" method="post">
            <table class="table table-bordered table-hover table-striped">
           

                <tr>
                    <td>ID Number</td>
                    <td><?=$_GET["id"]?><input type="hidden" name="id" value="<?=$_GET["id"]?>"></td>
                </tr>
          
                <tr>
                    <td>IHIN Number</td>
                    <td><?=$_GET["ihin"]?><input type="hidden" name="ihin" value="<?=$_GET["ihin"]?>"></td>
                </tr>
                
                
            </table>
                <div class="col-md-6 col-md-offset-3">
                    <div class="col-md-4 col-sm-4 col-xs-4"><input type="submit" class="btn btn-success" value="Correct"></div>
                    <div class="col-md-4 col-sm-4 col-xs-4"> <a href="form8a.php" class="btn btn-info">Re-Enter</a></div>
                </div>
            </form>

            </div>
        </div>
    </div>
</div>

<?php

}

?>

</body>